# Nuraxi Foundry Demo Prototype
# King Faisal Specialist Hospital & Research Centre
# Version 1.0 - January 2026
