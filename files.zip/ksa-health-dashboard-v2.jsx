import React, { useState, useMemo } from 'react';

// ============================================================================
// ACCURATE KSA PROVINCE SVG PATHS
// Based on geographic boundaries - simplified for performance
// ============================================================================

const provincePaths = {
  // Northern Borders - الحدود الشمالية
  northern: {
    path: "M 245 28 L 285 18 L 340 15 L 395 22 L 430 35 L 445 52 L 420 68 L 375 72 L 330 78 L 285 75 L 250 70 L 225 55 L 235 38 Z",
    labelPos: { x: 335, y: 48 },
  },
  // Al-Jawf - الجوف  
  aljawf: {
    path: "M 165 45 L 195 35 L 245 28 L 235 38 L 225 55 L 250 70 L 240 95 L 210 110 L 175 105 L 150 85 L 155 60 Z",
    labelPos: { x: 200, y: 72 },
  },
  // Tabuk - تبوك
  tabuk: {
    path: "M 85 68 L 120 52 L 165 45 L 155 60 L 150 85 L 175 105 L 165 140 L 145 175 L 110 195 L 75 185 L 55 155 L 45 120 L 55 90 L 70 75 Z",
    labelPos: { x: 110, y: 125 },
  },
  // Hail - حائل
  hail: {
    path: "M 250 70 L 285 75 L 330 78 L 340 105 L 325 140 L 290 155 L 255 150 L 225 135 L 210 110 L 240 95 Z",
    labelPos: { x: 275, y: 115 },
  },
  // Qassim - القصيم
  qassim: {
    path: "M 290 155 L 325 140 L 360 148 L 380 175 L 365 210 L 330 225 L 295 215 L 275 185 L 275 165 Z",
    labelPos: { x: 325, y: 182 },
  },
  // Eastern Province - المنطقة الشرقية
  eastern: {
    path: "M 330 78 L 375 72 L 420 68 L 445 52 L 475 70 L 495 105 L 510 150 L 515 200 L 505 260 L 485 310 L 455 340 L 420 355 L 385 345 L 365 310 L 375 265 L 385 220 L 380 175 L 360 148 L 340 105 Z",
    labelPos: { x: 445, y: 195 },
  },
  // Riyadh - الرياض
  riyadh: {
    path: "M 255 150 L 290 155 L 275 165 L 275 185 L 295 215 L 330 225 L 365 210 L 380 175 L 385 220 L 375 265 L 365 310 L 345 355 L 310 385 L 270 395 L 235 375 L 215 335 L 210 290 L 220 245 L 235 205 L 245 175 Z",
    labelPos: { x: 295, y: 275 },
  },
  // Madinah - المدينة المنورة
  madinah: {
    path: "M 145 175 L 165 140 L 175 105 L 210 110 L 225 135 L 255 150 L 245 175 L 235 205 L 220 245 L 195 265 L 160 255 L 130 235 L 115 210 L 110 195 Z",
    labelPos: { x: 175, y: 195 },
  },
  // Makkah - مكة المكرمة
  makkah: {
    path: "M 75 185 L 110 195 L 115 210 L 130 235 L 160 255 L 195 265 L 220 245 L 210 290 L 195 335 L 165 375 L 130 395 L 95 385 L 65 355 L 50 315 L 45 275 L 50 235 L 60 210 Z",
    labelPos: { x: 125, y: 300 },
  },
  // Al-Bahah - الباحة
  albahah: {
    path: "M 95 385 L 130 395 L 145 420 L 135 445 L 110 455 L 85 445 L 75 420 L 80 400 Z",
    labelPos: { x: 110, y: 425 },
  },
  // Asir - عسير
  asir: {
    path: "M 130 395 L 165 375 L 195 335 L 215 335 L 235 375 L 255 415 L 245 455 L 215 485 L 175 495 L 140 485 L 115 465 L 110 455 L 135 445 L 145 420 Z",
    labelPos: { x: 185, y: 435 },
  },
  // Najran - نجران
  najran: {
    path: "M 235 375 L 270 395 L 310 385 L 345 355 L 365 310 L 385 345 L 395 390 L 375 430 L 340 455 L 295 465 L 255 455 L 245 455 L 255 415 Z",
    labelPos: { x: 315, y: 410 },
  },
  // Jazan - جازان
  jazan: {
    path: "M 85 445 L 110 455 L 115 465 L 140 485 L 130 510 L 105 525 L 75 520 L 55 500 L 55 475 L 65 455 Z",
    labelPos: { x: 95, y: 485 },
  },
};

// ============================================================================
// REAL KSA DATA FROM RESEARCH
// ============================================================================

const provinceData = {
  riyadh: {
    name: 'Riyadh', nameAr: 'الرياض',
    population: 8591748, popPercent: 26.7,
    diabetes: 8.8, hypertension: 8.2, cvd: 1.7, obesity: 29.5, cancer: 176,
    bedsPerCapita: 29.4, phcPerCapita: 1.8,
    inactivity: 97.3, smoking: 12.1,
    diabetesMortality: 6494, cvdMortality: 864,
    undiagnosedRisk: 'moderate',
    tier: 2, trend: 'stable',
    capital: 'Riyadh',
  },
  makkah: {
    name: 'Makkah', nameAr: 'مكة المكرمة',
    population: 8021463, popPercent: 24.9,
    diabetes: 9.3, hypertension: 10.0, cvd: 2.1, obesity: 30.2, cancer: 96,
    bedsPerCapita: 20.1, phcPerCapita: 1.24,
    inactivity: 96.5, smoking: 11.8,
    diabetesMortality: 7931, cvdMortality: 1168,
    undiagnosedRisk: 'moderate',
    tier: 1, trend: 'worsening',
    capital: 'Makkah',
  },
  eastern: {
    name: 'Eastern', nameAr: 'المنطقة الشرقية',
    population: 5125254, popPercent: 15.9,
    diabetes: 8.6, hypertension: 8.5, cvd: 1.8, obesity: 29.8, cancer: 336,
    bedsPerCapita: 25.2, phcPerCapita: 2.1,
    inactivity: 95.8, smoking: 17.0,
    diabetesMortality: 6200, cvdMortality: 920,
    undiagnosedRisk: 'moderate',
    tier: 1, trend: 'worsening',
    capital: 'Dammam',
  },
  madinah: {
    name: 'Madinah', nameAr: 'المدينة المنورة',
    population: 2137983, popPercent: 6.6,
    diabetes: 7.8, hypertension: 7.5, cvd: 1.5, obesity: 28.5, cancer: 145,
    bedsPerCapita: 26.8, phcPerCapita: 2.3,
    inactivity: 95.2, smoking: 10.5,
    diabetesMortality: 5800, cvdMortality: 780,
    undiagnosedRisk: 'moderate',
    tier: 3, trend: 'stable',
    capital: 'Madinah',
  },
  asir: {
    name: 'Asir', nameAr: 'عسير',
    population: 2024285, popPercent: 6.3,
    diabetes: 7.2, hypertension: 7.0, cvd: 1.4, obesity: 27.8, cancer: 130,
    bedsPerCapita: 28.5, phcPerCapita: 2.8,
    inactivity: 94.0, smoking: 8.5,
    diabetesMortality: 5400, cvdMortality: 720,
    undiagnosedRisk: 'high',
    tier: 4, trend: 'improving',
    capital: 'Abha',
  },
  jazan: {
    name: 'Jazan', nameAr: 'جازان',
    population: 1404997, popPercent: 4.4,
    diabetes: 6.5, hypertension: 6.8, cvd: 1.3, obesity: 26.5, cancer: 160,
    bedsPerCapita: 21.2, phcPerCapita: 1.9,
    inactivity: 94.5, smoking: 9.2,
    diabetesMortality: 6817, cvdMortality: 784,
    undiagnosedRisk: 'very high',
    tier: 1, trend: 'worsening',
    capital: 'Jazan',
  },
  qassim: {
    name: 'Qassim', nameAr: 'القصيم',
    population: 1336179, popPercent: 4.2,
    diabetes: 7.5, hypertension: 7.2, cvd: 1.4, obesity: 28.2, cancer: 140,
    bedsPerCapita: 27.5, phcPerCapita: 2.5,
    inactivity: 95.5, smoking: 11.0,
    diabetesMortality: 5600, cvdMortality: 750,
    undiagnosedRisk: 'moderate',
    tier: 4, trend: 'stable',
    capital: 'Buraidah',
  },
  tabuk: {
    name: 'Tabuk', nameAr: 'تبوك',
    population: 886036, popPercent: 2.8,
    diabetes: 7.0, hypertension: 6.8, cvd: 1.2, obesity: 27.5, cancer: 125,
    bedsPerCapita: 24.8, phcPerCapita: 2.4,
    inactivity: 95.0, smoking: 12.5,
    diabetesMortality: 5200, cvdMortality: 680,
    undiagnosedRisk: 'high',
    tier: 4, trend: 'stable',
    capital: 'Tabuk',
  },
  hail: {
    name: 'Hail', nameAr: 'حائل',
    population: 746406, popPercent: 2.3,
    diabetes: 8.0, hypertension: 7.8, cvd: 1.5, obesity: 29.0, cancer: 155,
    bedsPerCapita: 26.2, phcPerCapita: 2.6,
    inactivity: 95.8, smoking: 13.0,
    diabetesMortality: 7072, cvdMortality: 880,
    undiagnosedRisk: 'high',
    tier: 2, trend: 'worsening',
    capital: 'Hail',
  },
  aljawf: {
    name: 'Al-Jawf', nameAr: 'الجوف',
    population: 595822, popPercent: 1.9,
    diabetes: 6.8, hypertension: 6.5, cvd: 1.2, obesity: 27.0, cancer: 118,
    bedsPerCapita: 30.6, phcPerCapita: 3.2,
    inactivity: 94.8, smoking: 15.5,
    diabetesMortality: 5100, cvdMortality: 650,
    undiagnosedRisk: 'high',
    tier: 3, trend: 'stable',
    capital: 'Sakakah',
  },
  najran: {
    name: 'Najran', nameAr: 'نجران',
    population: 592300, popPercent: 1.8,
    diabetes: 6.1, hypertension: 6.0, cvd: 1.0, obesity: 25.5, cancer: 143,
    bedsPerCapita: 28.8, phcPerCapita: 3.0,
    inactivity: 94.0, smoking: 8.0,
    diabetesMortality: 4699, cvdMortality: 385,
    undiagnosedRisk: 'very high',
    tier: 4, trend: 'improving',
    capital: 'Najran',
  },
  northern: {
    name: 'Northern Borders', nameAr: 'الحدود الشمالية',
    population: 373577, popPercent: 1.2,
    diabetes: 6.5, hypertension: 6.2, cvd: 1.1, obesity: 26.8, cancer: 120,
    bedsPerCapita: 36.0, phcPerCapita: 3.8,
    inactivity: 94.2, smoking: 16.0,
    diabetesMortality: 4900, cvdMortality: 620,
    undiagnosedRisk: 'high',
    tier: 3, trend: 'stable',
    capital: 'Arar',
  },
  albahah: {
    name: 'Al-Bahah', nameAr: 'الباحة',
    population: 339174, popPercent: 1.1,
    diabetes: 7.4, hypertension: 8.5, cvd: 1.6, obesity: 28.8, cancer: 113,
    bedsPerCapita: 35.7, phcPerCapita: 3.92,
    inactivity: 94.5, smoking: 8.8,
    diabetesMortality: 6264, cvdMortality: 1056,
    undiagnosedRisk: 'high',
    tier: 2, trend: 'worsening',
    capital: 'Al-Bahah',
  },
};

// National aggregates
const nationalStats = {
  population: 35300000,
  diabetesPrevalence: 16.4,
  obesityRate: 78.6,
  undiagnosedDiabetes: 58,
  physicalInactivity: 96.1,
  lifeExpectancy: 78.8,
  healthyLifeExpectancy: 65,
};

// Vision 2030 KPIs
const vision2030KPIs = [
  { name: 'Life Expectancy', current: 78.8, target: 80, unit: 'years', status: 'on-track' },
  { name: 'UHC Index', current: 83, target: 90, unit: 'points', status: 'on-track' },
  { name: 'Physical Activity', current: 58.5, target: 65, unit: '%', status: 'at-risk' },
  { name: 'Obesity Reduction', current: -2, target: -10, unit: '% change', status: 'off-track' },
  { name: 'Digital Health', current: 80, target: 100, unit: '%', status: 'on-track' },
];

// ============================================================================
// DESIGN SYSTEM
// ============================================================================

const colors = {
  bg: {
    primary: '#0A0F1A',
    secondary: '#0F1729',
    tertiary: '#162032',
    card: 'rgba(22, 32, 50, 0.8)',
  },
  accent: {
    primary: '#00E5BF',
    primaryDim: 'rgba(0, 229, 191, 0.15)',
    secondary: '#3B82F6',
    warning: '#F59E0B',
    warningDim: 'rgba(245, 158, 11, 0.15)',
    danger: '#EF4444',
    dangerDim: 'rgba(239, 68, 68, 0.15)',
    success: '#10B981',
  },
  text: {
    primary: '#F1F5F9',
    secondary: '#94A3B8',
    muted: '#64748B',
  },
  border: 'rgba(148, 163, 184, 0.1)',
};

const tierColors = {
  1: colors.accent.danger,
  2: colors.accent.warning,
  3: colors.accent.secondary,
  4: colors.accent.success,
};

const tierLabels = {
  1: 'Critical',
  2: 'High Priority',
  3: 'Moderate',
  4: 'Monitor',
};

// ============================================================================
// INTERACTIVE KSA MAP COMPONENT
// ============================================================================

const KSAMap = ({ selectedProvince, onProvinceClick, colorMode = 'tier', metric = null }) => {
  const [hoveredProvince, setHoveredProvince] = useState(null);
  
  const getProvinceColor = (key, data) => {
    if (colorMode === 'tier') {
      return tierColors[data.tier];
    }
    if (colorMode === 'metric' && metric) {
      const value = data[metric];
      const ranges = {
        diabetes: { min: 6, max: 10 },
        hypertension: { min: 6, max: 10 },
        obesity: { min: 25, max: 31 },
        bedsPerCapita: { min: 20, max: 36 },
        inactivity: { min: 94, max: 98 },
      };
      const range = ranges[metric] || { min: 0, max: 100 };
      const normalized = (value - range.min) / (range.max - range.min);
      
      if (metric === 'bedsPerCapita') {
        // Higher is better for beds
        return normalized > 0.6 ? colors.accent.success : normalized > 0.3 ? colors.accent.warning : colors.accent.danger;
      }
      // Higher is worse for most metrics
      return normalized > 0.6 ? colors.accent.danger : normalized > 0.3 ? colors.accent.warning : colors.accent.success;
    }
    return colors.accent.secondary;
  };
  
  const activeProvince = hoveredProvince || selectedProvince;
  const activeData = activeProvince ? provinceData[activeProvince] : null;
  
  return (
    <div style={{
      background: colors.bg.card,
      borderRadius: 16,
      padding: 24,
      border: `1px solid ${colors.border}`,
      position: 'relative',
    }}>
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 16,
      }}>
        <div>
          <div style={{
            fontSize: 11,
            color: colors.text.muted,
            textTransform: 'uppercase',
            letterSpacing: '1px',
          }}>Kingdom of Saudi Arabia</div>
          <div style={{ fontSize: 14, color: colors.text.secondary, marginTop: 2 }}>
            {colorMode === 'tier' ? 'Health Risk Priority Map' : `${metric?.charAt(0).toUpperCase()}${metric?.slice(1)} Distribution`}
          </div>
        </div>
        {activeProvince && (
          <div style={{
            background: colors.bg.tertiary,
            padding: '8px 12px',
            borderRadius: 8,
            textAlign: 'right',
          }}>
            <div style={{ fontSize: 12, color: colors.text.secondary }}>{activeData?.nameAr}</div>
            <div style={{ fontSize: 14, fontWeight: 600, color: colors.text.primary }}>{activeData?.name}</div>
          </div>
        )}
      </div>
      
      <div style={{ position: 'relative' }}>
        <svg 
          viewBox="0 0 560 550" 
          style={{ 
            width: '100%', 
            height: 'auto',
            maxHeight: 420,
          }}
        >
          {/* Background */}
          <defs>
            <linearGradient id="mapGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor={colors.bg.tertiary} />
              <stop offset="100%" stopColor={colors.bg.secondary} />
            </linearGradient>
            <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
              <feMerge>
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>
            <filter id="shadow">
              <feDropShadow dx="0" dy="2" stdDeviation="3" floodOpacity="0.3"/>
            </filter>
          </defs>
          
          {/* Water/background */}
          <rect x="0" y="0" width="560" height="550" fill="url(#mapGradient)" rx="8" />
          
          {/* Province shapes */}
          {Object.entries(provincePaths).map(([key, { path }]) => {
            const data = provinceData[key];
            const isSelected = selectedProvince === key;
            const isHovered = hoveredProvince === key;
            const fillColor = getProvinceColor(key, data);
            
            return (
              <g key={key}>
                <path
                  d={path}
                  fill={fillColor}
                  fillOpacity={isSelected ? 0.9 : isHovered ? 0.75 : 0.5}
                  stroke={isSelected ? colors.text.primary : isHovered ? fillColor : colors.border}
                  strokeWidth={isSelected ? 2.5 : isHovered ? 2 : 1}
                  style={{
                    cursor: 'pointer',
                    transition: 'all 0.2s ease',
                    filter: isSelected ? 'url(#glow)' : 'none',
                  }}
                  onClick={() => onProvinceClick(key)}
                  onMouseEnter={() => setHoveredProvince(key)}
                  onMouseLeave={() => setHoveredProvince(null)}
                />
              </g>
            );
          })}
          
          {/* Province labels */}
          {Object.entries(provincePaths).map(([key, { labelPos }]) => {
            const data = provinceData[key];
            const isSelected = selectedProvince === key;
            const isHovered = hoveredProvince === key;
            const show = isSelected || isHovered || data.population > 2000000;
            
            if (!show) return null;
            
            return (
              <g key={`label-${key}`} style={{ pointerEvents: 'none' }}>
                <text
                  x={labelPos.x}
                  y={labelPos.y}
                  fill={colors.text.primary}
                  fontSize={isSelected || isHovered ? 11 : 9}
                  fontWeight={isSelected ? 700 : 500}
                  textAnchor="middle"
                  style={{ 
                    textShadow: '0 1px 3px rgba(0,0,0,0.8)',
                    transition: 'all 0.2s',
                  }}
                >
                  {data.name.split(' ')[0]}
                </text>
                {(isSelected || isHovered) && (
                  <text
                    x={labelPos.x}
                    y={labelPos.y + 14}
                    fill={colors.text.secondary}
                    fontSize={9}
                    textAnchor="middle"
                    style={{ textShadow: '0 1px 3px rgba(0,0,0,0.8)' }}
                  >
                    {(data.population / 1000000).toFixed(1)}M
                  </text>
                )}
              </g>
            );
          })}
          
          {/* Neighboring countries labels */}
          <text x="480" y="35" fill={colors.text.muted} fontSize="9" opacity="0.5">IRAQ</text>
          <text x="175" y="20" fill={colors.text.muted} fontSize="9" opacity="0.5">JORDAN</text>
          <text x="30" y="250" fill={colors.text.muted} fontSize="9" opacity="0.5" transform="rotate(-90, 30, 250)">RED SEA</text>
          <text x="520" y="280" fill={colors.text.muted} fontSize="9" opacity="0.5" transform="rotate(90, 520, 280)">GULF</text>
          <text x="280" y="540" fill={colors.text.muted} fontSize="9" opacity="0.5">YEMEN</text>
          <text x="450" y="480" fill={colors.text.muted} fontSize="9" opacity="0.5">OMAN</text>
        </svg>
        
        {/* Hover tooltip */}
        {hoveredProvince && !selectedProvince && (
          <div style={{
            position: 'absolute',
            bottom: 16,
            left: 16,
            right: 16,
            background: colors.bg.primary,
            borderRadius: 12,
            padding: 16,
            border: `1px solid ${colors.border}`,
            display: 'grid',
            gridTemplateColumns: 'repeat(4, 1fr)',
            gap: 12,
          }}>
            <div>
              <div style={{ fontSize: 10, color: colors.text.muted }}>DIABETES</div>
              <div style={{ fontSize: 16, fontWeight: 600, color: activeData.diabetes > 8 ? colors.accent.danger : colors.text.primary }}>
                {activeData.diabetes}%
              </div>
            </div>
            <div>
              <div style={{ fontSize: 10, color: colors.text.muted }}>HYPERTENSION</div>
              <div style={{ fontSize: 16, fontWeight: 600, color: activeData.hypertension > 8 ? colors.accent.danger : colors.text.primary }}>
                {activeData.hypertension}%
              </div>
            </div>
            <div>
              <div style={{ fontSize: 10, color: colors.text.muted }}>BEDS/10K</div>
              <div style={{ fontSize: 16, fontWeight: 600, color: activeData.bedsPerCapita < 23 ? colors.accent.danger : colors.text.primary }}>
                {activeData.bedsPerCapita}
              </div>
            </div>
            <div>
              <div style={{ fontSize: 10, color: colors.text.muted }}>PRIORITY</div>
              <div style={{ 
                fontSize: 12, 
                fontWeight: 600, 
                color: tierColors[activeData.tier],
                padding: '4px 8px',
                background: tierColors[activeData.tier] + '20',
                borderRadius: 4,
                display: 'inline-block',
              }}>
                {tierLabels[activeData.tier]}
              </div>
            </div>
          </div>
        )}
      </div>
      
      {/* Legend */}
      <div style={{
        display: 'flex',
        justifyContent: 'center',
        gap: 20,
        marginTop: 16,
        paddingTop: 16,
        borderTop: `1px solid ${colors.border}`,
      }}>
        {Object.entries(tierLabels).map(([tier, label]) => (
          <div key={tier} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{
              width: 12,
              height: 12,
              borderRadius: 3,
              background: tierColors[tier],
              opacity: 0.7,
            }} />
            <span style={{ fontSize: 11, color: colors.text.muted }}>{label}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

// ============================================================================
// PROVINCE DETAIL PANEL
// ============================================================================

const ProvinceDetailPanel = ({ provinceKey, onClose }) => {
  const province = provinceData[provinceKey];
  const pathData = provincePaths[provinceKey];
  
  if (!province) return null;
  
  const metrics = [
    { label: 'Diabetes', value: province.diabetes, unit: '%', danger: 8 },
    { label: 'Hypertension', value: province.hypertension, unit: '%', danger: 8 },
    { label: 'CVD', value: province.cvd, unit: '%', danger: 1.8 },
    { label: 'Obesity', value: province.obesity, unit: '%', danger: 29 },
    { label: 'Physical Inactivity', value: province.inactivity, unit: '%', danger: 96 },
    { label: 'Smoking', value: province.smoking, unit: '%', danger: 14 },
  ];
  
  const infrastructure = [
    { label: 'Hospital Beds', value: province.bedsPerCapita, unit: '/10K', good: 25 },
    { label: 'Primary Care', value: province.phcPerCapita, unit: '/10K', good: 2.5 },
  ];
  
  return (
    <div style={{
      background: colors.bg.card,
      borderRadius: 16,
      border: `1px solid ${colors.border}`,
      overflow: 'hidden',
    }}>
      {/* Header */}
      <div style={{
        padding: 20,
        background: `linear-gradient(135deg, ${tierColors[province.tier]}20, transparent)`,
        borderBottom: `1px solid ${colors.border}`,
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
      }}>
        <div>
          <div style={{ fontSize: 11, color: colors.text.muted, marginBottom: 4 }}>
            {province.nameAr}
          </div>
          <h2 style={{ margin: 0, fontSize: 24, fontWeight: 700 }}>{province.name}</h2>
          <div style={{ fontSize: 13, color: colors.text.secondary, marginTop: 4 }}>
            Capital: {province.capital} • {(province.population / 1000000).toFixed(2)}M population
          </div>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 8 }}>
          <div style={{
            padding: '6px 12px',
            borderRadius: 8,
            background: tierColors[province.tier] + '20',
            color: tierColors[province.tier],
            fontSize: 12,
            fontWeight: 600,
          }}>
            {tierLabels[province.tier]}
          </div>
          <div style={{
            fontSize: 11,
            color: province.trend === 'improving' ? colors.accent.success 
                 : province.trend === 'worsening' ? colors.accent.danger 
                 : colors.text.muted,
          }}>
            {province.trend === 'improving' ? '↑ Improving' 
             : province.trend === 'worsening' ? '↓ Worsening' 
             : '→ Stable'}
          </div>
        </div>
      </div>
      
      {/* Mini map */}
      <div style={{ padding: '16px 20px', borderBottom: `1px solid ${colors.border}` }}>
        <svg viewBox="0 0 560 550" style={{ width: '100%', height: 80, opacity: 0.6 }}>
          {Object.entries(provincePaths).map(([key, { path }]) => (
            <path
              key={key}
              d={path}
              fill={key === provinceKey ? tierColors[province.tier] : colors.bg.tertiary}
              stroke={colors.border}
              strokeWidth={0.5}
            />
          ))}
        </svg>
      </div>
      
      {/* Metrics */}
      <div style={{ padding: 20 }}>
        <div style={{
          fontSize: 11,
          color: colors.text.muted,
          textTransform: 'uppercase',
          letterSpacing: '0.5px',
          marginBottom: 12,
        }}>Disease Prevalence</div>
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(3, 1fr)',
          gap: 12,
        }}>
          {metrics.map((m, i) => (
            <div key={i} style={{
              background: colors.bg.tertiary,
              borderRadius: 8,
              padding: 12,
            }}>
              <div style={{ fontSize: 10, color: colors.text.muted, marginBottom: 4 }}>{m.label}</div>
              <div style={{
                fontSize: 20,
                fontWeight: 700,
                color: m.value >= m.danger ? colors.accent.danger : colors.text.primary,
              }}>
                {m.value}{m.unit}
              </div>
            </div>
          ))}
        </div>
        
        <div style={{
          fontSize: 11,
          color: colors.text.muted,
          textTransform: 'uppercase',
          letterSpacing: '0.5px',
          marginTop: 20,
          marginBottom: 12,
        }}>Healthcare Infrastructure</div>
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(2, 1fr)',
          gap: 12,
        }}>
          {infrastructure.map((m, i) => (
            <div key={i} style={{
              background: colors.bg.tertiary,
              borderRadius: 8,
              padding: 12,
            }}>
              <div style={{ fontSize: 10, color: colors.text.muted, marginBottom: 4 }}>{m.label}</div>
              <div style={{
                fontSize: 20,
                fontWeight: 700,
                color: m.value >= m.good ? colors.accent.success : colors.accent.warning,
              }}>
                {m.value}{m.unit}
              </div>
            </div>
          ))}
        </div>
        
        {/* Mortality */}
        <div style={{
          marginTop: 20,
          padding: 16,
          background: colors.accent.dangerDim,
          borderRadius: 8,
          border: `1px solid ${colors.accent.danger}30`,
        }}>
          <div style={{ fontSize: 11, color: colors.accent.danger, marginBottom: 8 }}>
            ANNUAL MORTALITY PER 100,000
          </div>
          <div style={{ display: 'flex', gap: 24 }}>
            <div>
              <span style={{ fontSize: 24, fontWeight: 700, color: colors.text.primary }}>
                {province.diabetesMortality.toLocaleString()}
              </span>
              <span style={{ fontSize: 12, color: colors.text.muted, marginLeft: 6 }}>Diabetes</span>
            </div>
            <div>
              <span style={{ fontSize: 24, fontWeight: 700, color: colors.text.primary }}>
                {province.cvdMortality.toLocaleString()}
              </span>
              <span style={{ fontSize: 12, color: colors.text.muted, marginLeft: 6 }}>CVD</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// STATS COMPONENTS
// ============================================================================

const StatCard = ({ label, value, subtext, trend, color = colors.accent.primary, small }) => (
  <div style={{
    background: colors.bg.card,
    borderRadius: 12,
    padding: small ? '14px 16px' : '20px 24px',
    border: `1px solid ${colors.border}`,
    position: 'relative',
    overflow: 'hidden',
  }}>
    <div style={{
      position: 'absolute',
      top: 0,
      left: 0,
      width: 3,
      height: '100%',
      background: color,
    }} />
    <div style={{
      fontSize: small ? 10 : 11,
      color: colors.text.muted,
      textTransform: 'uppercase',
      letterSpacing: '0.5px',
      marginBottom: 6,
    }}>{label}</div>
    <div style={{
      fontSize: small ? 24 : 32,
      fontWeight: 700,
      color: color,
      display: 'flex',
      alignItems: 'baseline',
      gap: 8,
    }}>
      {value}
      {trend !== undefined && (
        <span style={{
          fontSize: 12,
          color: trend > 0 ? colors.accent.success : colors.accent.danger,
        }}>
          {trend > 0 ? '↑' : '↓'} {Math.abs(trend)}%
        </span>
      )}
    </div>
    {subtext && (
      <div style={{
        fontSize: small ? 11 : 12,
        color: colors.text.secondary,
        marginTop: 4,
      }}>{subtext}</div>
    )}
  </div>
);

// ============================================================================
// VISION 2030 TRACKER
// ============================================================================

const Vision2030Tracker = () => {
  const statusColors = {
    'on-track': colors.accent.success,
    'at-risk': colors.accent.warning,
    'off-track': colors.accent.danger,
  };
  
  return (
    <div style={{
      background: colors.bg.card,
      borderRadius: 16,
      padding: 24,
      border: `1px solid ${colors.border}`,
    }}>
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 20,
      }}>
        <div style={{
          fontSize: 11,
          color: colors.text.muted,
          textTransform: 'uppercase',
          letterSpacing: '1px',
        }}>Vision 2030 Health KPIs</div>
        <div style={{
          background: colors.accent.primaryDim,
          padding: '4px 10px',
          borderRadius: 6,
          fontSize: 10,
          color: colors.accent.primary,
        }}>LIVE TRACKING</div>
      </div>
      
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        {vision2030KPIs.map((kpi, i) => {
          const percent = Math.min((kpi.current / kpi.target) * 100, 100);
          return (
            <div key={i}>
              <div style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                marginBottom: 6,
              }}>
                <span style={{ fontSize: 13, color: colors.text.primary }}>{kpi.name}</span>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ fontSize: 13, fontWeight: 600, color: statusColors[kpi.status] }}>
                    {kpi.current}{kpi.unit.includes('%') ? '%' : ''} 
                  </span>
                  <span style={{
                    fontSize: 9,
                    padding: '2px 6px',
                    borderRadius: 4,
                    background: statusColors[kpi.status] + '20',
                    color: statusColors[kpi.status],
                    textTransform: 'uppercase',
                  }}>
                    {kpi.status.replace('-', ' ')}
                  </span>
                </div>
              </div>
              <div style={{
                height: 6,
                background: colors.bg.tertiary,
                borderRadius: 3,
                overflow: 'hidden',
              }}>
                <div style={{
                  width: `${percent}%`,
                  height: '100%',
                  background: statusColors[kpi.status],
                  borderRadius: 3,
                  transition: 'width 0.5s ease',
                }} />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

// ============================================================================
// PROVINCE TABLE
// ============================================================================

const ProvinceTable = ({ onProvinceClick, selectedProvince }) => {
  const [sortKey, setSortKey] = useState('tier');
  const [sortDir, setSortDir] = useState('asc');
  
  const sortedProvinces = Object.entries(provinceData)
    .sort(([, a], [, b]) => {
      const aVal = a[sortKey];
      const bVal = b[sortKey];
      if (typeof aVal === 'string') return sortDir === 'asc' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
      return sortDir === 'asc' ? aVal - bVal : bVal - aVal;
    });
  
  const handleSort = (key) => {
    if (sortKey === key) {
      setSortDir(sortDir === 'asc' ? 'desc' : 'asc');
    } else {
      setSortKey(key);
      setSortDir('desc');
    }
  };
  
  return (
    <div style={{
      background: colors.bg.card,
      borderRadius: 16,
      border: `1px solid ${colors.border}`,
      overflow: 'hidden',
    }}>
      <div style={{
        padding: '16px 24px',
        borderBottom: `1px solid ${colors.border}`,
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
      }}>
        <div style={{
          fontSize: 11,
          color: colors.text.muted,
          textTransform: 'uppercase',
          letterSpacing: '1px',
        }}>Provincial Health Comparison</div>
        <div style={{ fontSize: 11, color: colors.text.muted }}>
          Click headers to sort • Click row for details
        </div>
      </div>
      
      <div style={{ overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 900 }}>
          <thead>
            <tr style={{ background: colors.bg.tertiary }}>
              {[
                { key: 'name', label: 'Province' },
                { key: 'population', label: 'Population' },
                { key: 'diabetes', label: 'Diabetes %' },
                { key: 'hypertension', label: 'HTN %' },
                { key: 'obesity', label: 'Obesity %' },
                { key: 'bedsPerCapita', label: 'Beds/10K' },
                { key: 'inactivity', label: 'Inactive %' },
                { key: 'tier', label: 'Priority' },
                { key: 'trend', label: 'Trend' },
              ].map(col => (
                <th
                  key={col.key}
                  onClick={() => handleSort(col.key)}
                  style={{
                    padding: '12px 16px',
                    textAlign: 'left',
                    fontSize: 11,
                    fontWeight: 600,
                    color: colors.text.secondary,
                    cursor: 'pointer',
                    whiteSpace: 'nowrap',
                    userSelect: 'none',
                  }}
                >
                  {col.label}
                  {sortKey === col.key && (
                    <span style={{ marginLeft: 4 }}>{sortDir === 'asc' ? '↑' : '↓'}</span>
                  )}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {sortedProvinces.map(([key, p]) => (
              <tr
                key={key}
                onClick={() => onProvinceClick(key)}
                style={{
                  borderBottom: `1px solid ${colors.border}`,
                  cursor: 'pointer',
                  background: selectedProvince === key ? colors.bg.tertiary : 'transparent',
                  transition: 'background 0.2s',
                }}
              >
                <td style={{ padding: '12px 16px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <div style={{
                      width: 8,
                      height: 8,
                      borderRadius: 4,
                      background: tierColors[p.tier],
                    }} />
                    <div>
                      <div style={{ fontWeight: 500, color: colors.text.primary }}>{p.name}</div>
                      <div style={{ fontSize: 10, color: colors.text.muted }}>{p.nameAr}</div>
                    </div>
                  </div>
                </td>
                <td style={{ padding: '12px 16px', color: colors.text.secondary, fontSize: 13 }}>
                  {(p.population / 1000000).toFixed(2)}M
                </td>
                <td style={{ padding: '12px 16px' }}>
                  <span style={{
                    color: p.diabetes > 8 ? colors.accent.danger : p.diabetes > 7 ? colors.accent.warning : colors.text.secondary,
                    fontWeight: p.diabetes > 8 ? 600 : 400,
                  }}>{p.diabetes}%</span>
                </td>
                <td style={{ padding: '12px 16px' }}>
                  <span style={{
                    color: p.hypertension > 8 ? colors.accent.danger : colors.text.secondary,
                  }}>{p.hypertension}%</span>
                </td>
                <td style={{ padding: '12px 16px', color: colors.text.secondary }}>{p.obesity}%</td>
                <td style={{ padding: '12px 16px' }}>
                  <span style={{
                    color: p.bedsPerCapita < 23 ? colors.accent.danger : colors.accent.success,
                  }}>{p.bedsPerCapita}</span>
                </td>
                <td style={{ padding: '12px 16px', color: colors.text.muted }}>{p.inactivity}%</td>
                <td style={{ padding: '12px 16px' }}>
                  <span style={{
                    padding: '4px 10px',
                    borderRadius: 6,
                    fontSize: 11,
                    fontWeight: 500,
                    background: tierColors[p.tier] + '20',
                    color: tierColors[p.tier],
                  }}>
                    {tierLabels[p.tier]}
                  </span>
                </td>
                <td style={{ padding: '12px 16px' }}>
                  <span style={{
                    color: p.trend === 'improving' ? colors.accent.success 
                         : p.trend === 'worsening' ? colors.accent.danger 
                         : colors.text.muted,
                  }}>
                    {p.trend === 'improving' ? '↑' : p.trend === 'worsening' ? '↓' : '→'}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// ============================================================================
// MAIN DASHBOARD
// ============================================================================

export default function KSAHealthDashboard() {
  const [currentView, setCurrentView] = useState('national');
  const [selectedProvince, setSelectedProvince] = useState(null);
  
  const handleProvinceClick = (key) => {
    setSelectedProvince(selectedProvince === key ? null : key);
  };
  
  return (
    <div style={{
      minHeight: '100vh',
      background: colors.bg.primary,
      color: colors.text.primary,
      fontFamily: '"SF Pro Display", -apple-system, BlinkMacSystemFont, sans-serif',
    }}>
      {/* Header */}
      <header style={{
        padding: '20px 32px',
        borderBottom: `1px solid ${colors.border}`,
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <div style={{
            background: `linear-gradient(135deg, ${colors.accent.primary}, ${colors.accent.secondary})`,
            padding: '8px 14px',
            borderRadius: 8,
            fontSize: 12,
            fontWeight: 700,
            letterSpacing: '1px',
          }}>
            NURAXI VITRUVIA
          </div>
          <div>
            <h1 style={{ fontSize: 20, fontWeight: 600, margin: 0 }}>
              Kingdom of Saudi Arabia
            </h1>
            <p style={{ fontSize: 12, color: colors.text.muted, margin: 0 }}>
              National Health Intelligence Dashboard • Vision 2030
            </p>
          </div>
        </div>
        
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{
            padding: '6px 12px',
            background: colors.accent.primaryDim,
            borderRadius: 6,
            fontSize: 11,
            color: colors.accent.primary,
          }}>
            🔒 Sovereign Data
          </div>
          <div style={{
            padding: '6px 12px',
            background: colors.bg.tertiary,
            borderRadius: 6,
            fontSize: 11,
            color: colors.text.secondary,
            cursor: 'pointer',
          }}>
            عربي | EN
          </div>
        </div>
      </header>
      
      {/* Navigation */}
      <nav style={{
        padding: '12px 32px',
        borderBottom: `1px solid ${colors.border}`,
        display: 'flex',
        gap: 8,
      }}>
        {[
          { id: 'national', label: 'National Overview', icon: '🏛️' },
          { id: 'provincial', label: 'Provincial Analysis', icon: '🗺️' },
          { id: 'disease', label: 'Disease Deep-Dive', icon: '🩺' },
          { id: 'intervention', label: 'Intervention Modeling', icon: '🎯' },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => { setCurrentView(tab.id); setSelectedProvince(null); }}
            style={{
              padding: '10px 18px',
              background: currentView === tab.id ? colors.accent.primary : 'transparent',
              color: currentView === tab.id ? colors.bg.primary : colors.text.secondary,
              border: `1px solid ${currentView === tab.id ? colors.accent.primary : colors.border}`,
              borderRadius: 8,
              fontSize: 13,
              fontWeight: 500,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              transition: 'all 0.2s',
            }}
          >
            <span>{tab.icon}</span>
            {tab.label}
          </button>
        ))}
      </nav>
      
      {/* Main Content */}
      <main style={{ padding: 32 }}>
        {currentView === 'national' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
            {/* Stats row */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(5, 1fr)',
              gap: 16,
            }}>
              <StatCard
                label="Total Population"
                value="35.3M"
                subtext="2024 estimate"
                color={colors.accent.primary}
              />
              <StatCard
                label="Diabetes Prevalence"
                value="16.4%"
                subtext="~5.8M affected"
                color={colors.accent.danger}
              />
              <StatCard
                label="Undiagnosed NCDs"
                value="58%"
                subtext="Hidden burden"
                color={colors.accent.warning}
              />
              <StatCard
                label="Life Expectancy"
                value="78.8yr"
                subtext="Target: 80yr"
                color={colors.accent.success}
                trend={3}
              />
              <StatCard
                label="Healthy Life Years"
                value="65yr"
                subtext="13.8yr gap"
                color={colors.accent.secondary}
              />
            </div>
            
            {/* Map and details */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: selectedProvince ? '1fr 380px' : '1fr 350px',
              gap: 24,
            }}>
              <KSAMap
                selectedProvince={selectedProvince}
                onProvinceClick={handleProvinceClick}
                colorMode="tier"
              />
              {selectedProvince ? (
                <ProvinceDetailPanel
                  provinceKey={selectedProvince}
                  onClose={() => setSelectedProvince(null)}
                />
              ) : (
                <Vision2030Tracker />
              )}
            </div>
            
            {/* Table */}
            <ProvinceTable
              onProvinceClick={handleProvinceClick}
              selectedProvince={selectedProvince}
            />
          </div>
        )}
        
        {currentView === 'provincial' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(4, 1fr)',
              gap: 16,
            }}>
              <StatCard label="Critical Provinces" value="3" subtext="Makkah, Jazan, Eastern" color={colors.accent.danger} small />
              <StatCard label="High Priority" value="3" subtext="Riyadh, Hail, Al-Bahah" color={colors.accent.warning} small />
              <StatCard label="Infrastructure Gap" value="17K" subtext="Additional beds needed" color={colors.accent.secondary} small />
              <StatCard label="Model Province" value="Najran" subtext="Lowest NCD burden" color={colors.accent.success} small />
            </div>
            
            <div style={{
              display: 'grid',
              gridTemplateColumns: selectedProvince ? '1fr 400px' : '1fr',
              gap: 24,
            }}>
              <KSAMap
                selectedProvince={selectedProvince}
                onProvinceClick={handleProvinceClick}
                colorMode="tier"
              />
              {selectedProvince && (
                <ProvinceDetailPanel
                  provinceKey={selectedProvince}
                  onClose={() => setSelectedProvince(null)}
                />
              )}
            </div>
            
            <ProvinceTable
              onProvinceClick={handleProvinceClick}
              selectedProvince={selectedProvince}
            />
          </div>
        )}
        
        {(currentView === 'disease' || currentView === 'intervention') && (
          <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            height: 500,
            background: colors.bg.card,
            borderRadius: 16,
            border: `1px solid ${colors.border}`,
          }}>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 64, marginBottom: 16 }}>
                {currentView === 'disease' ? '🩺' : '🎯'}
              </div>
              <div style={{ fontSize: 20, color: colors.text.primary, marginBottom: 8 }}>
                {currentView === 'disease' ? 'Disease Analysis Module' : 'Intervention Modeling Engine'}
              </div>
              <div style={{ fontSize: 14, color: colors.text.muted, maxWidth: 400 }}>
                {currentView === 'disease' 
                  ? 'Deep-dive into Diabetes, CVD, Obesity, Cancer, and Mental Health with provincial breakdowns'
                  : 'AI-powered scenario modeling, cost-benefit analysis, and trajectory projections'
                }
              </div>
              <div style={{
                marginTop: 20,
                padding: '10px 20px',
                background: colors.accent.primaryDim,
                borderRadius: 8,
                fontSize: 13,
                color: colors.accent.primary,
                display: 'inline-block',
              }}>
                {currentView === 'disease' ? 'Coming in next iteration' : 'Powered by Vitruvia AI'}
              </div>
            </div>
          </div>
        )}
      </main>
      
      {/* Footer */}
      <footer style={{
        padding: '16px 32px',
        borderTop: `1px solid ${colors.border}`,
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        fontSize: 11,
        color: colors.text.muted,
      }}>
        <div>
          Data: GASTAT Census 2022 • Saudi Health Interview Survey • MOH Statistical Yearbook • IHME GBD
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <span>Sovereign Data • In-Kingdom Processing</span>
          <span style={{ color: colors.accent.primary }}>●</span>
          <span>Last updated: Jan 2025</span>
        </div>
      </footer>
    </div>
  );
}
