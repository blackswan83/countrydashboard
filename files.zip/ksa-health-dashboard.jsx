import React, { useState, useEffect } from 'react';

// ============================================================================
// REAL KSA DATA FROM RESEARCH
// ============================================================================

const provinceData = {
  riyadh: {
    name: 'Riyadh', nameAr: 'الرياض',
    population: 8591748, popPercent: 26.7,
    coordinates: { x: 55, y: 45 },
    diabetes: 8.8, hypertension: 8.2, cvd: 1.7, obesity: 29.5, cancer: 176,
    bedsPerCapita: 29.4, phcPerCapita: 1.8,
    inactivity: 97.3, smoking: 12.1,
    diabetesMortality: 6494, cvdMortality: 864,
    undiagnosedRisk: 'moderate',
    tier: 2, trend: 'stable',
  },
  makkah: {
    name: 'Makkah', nameAr: 'مكة المكرمة',
    population: 8021463, popPercent: 24.9,
    coordinates: { x: 28, y: 55 },
    diabetes: 9.3, hypertension: 10.0, cvd: 2.1, obesity: 30.2, cancer: 96,
    bedsPerCapita: 20.1, phcPerCapita: 1.24,
    inactivity: 96.5, smoking: 11.8,
    diabetesMortality: 7931, cvdMortality: 1168,
    undiagnosedRisk: 'moderate',
    tier: 1, trend: 'worsening',
  },
  eastern: {
    name: 'Eastern Province', nameAr: 'المنطقة الشرقية',
    population: 5125254, popPercent: 15.9,
    coordinates: { x: 75, y: 42 },
    diabetes: 8.6, hypertension: 8.5, cvd: 1.8, obesity: 29.8, cancer: 336,
    bedsPerCapita: 25.2, phcPerCapita: 2.1,
    inactivity: 95.8, smoking: 17.0,
    diabetesMortality: 6200, cvdMortality: 920,
    undiagnosedRisk: 'moderate',
    tier: 1, trend: 'worsening',
  },
  madinah: {
    name: 'Madinah', nameAr: 'المدينة المنورة',
    population: 2137983, popPercent: 6.6,
    coordinates: { x: 30, y: 38 },
    diabetes: 7.8, hypertension: 7.5, cvd: 1.5, obesity: 28.5, cancer: 145,
    bedsPerCapita: 26.8, phcPerCapita: 2.3,
    inactivity: 95.2, smoking: 10.5,
    diabetesMortality: 5800, cvdMortality: 780,
    undiagnosedRisk: 'moderate',
    tier: 3, trend: 'stable',
  },
  asir: {
    name: 'Asir', nameAr: 'عسير',
    population: 2024285, popPercent: 6.3,
    coordinates: { x: 38, y: 72 },
    diabetes: 7.2, hypertension: 7.0, cvd: 1.4, obesity: 27.8, cancer: 130,
    bedsPerCapita: 28.5, phcPerCapita: 2.8,
    inactivity: 94.0, smoking: 8.5,
    diabetesMortality: 5400, cvdMortality: 720,
    undiagnosedRisk: 'high',
    tier: 4, trend: 'improving',
  },
  jazan: {
    name: 'Jazan', nameAr: 'جازان',
    population: 1404997, popPercent: 4.4,
    coordinates: { x: 32, y: 82 },
    diabetes: 6.5, hypertension: 6.8, cvd: 1.3, obesity: 26.5, cancer: 160,
    bedsPerCapita: 21.2, phcPerCapita: 1.9,
    inactivity: 94.5, smoking: 9.2,
    diabetesMortality: 6817, cvdMortality: 784,
    undiagnosedRisk: 'very high',
    tier: 1, trend: 'worsening',
  },
  qassim: {
    name: 'Qassim', nameAr: 'القصيم',
    population: 1336179, popPercent: 4.2,
    coordinates: { x: 48, y: 35 },
    diabetes: 7.5, hypertension: 7.2, cvd: 1.4, obesity: 28.2, cancer: 140,
    bedsPerCapita: 27.5, phcPerCapita: 2.5,
    inactivity: 95.5, smoking: 11.0,
    diabetesMortality: 5600, cvdMortality: 750,
    undiagnosedRisk: 'moderate',
    tier: 4, trend: 'stable',
  },
  tabuk: {
    name: 'Tabuk', nameAr: 'تبوك',
    population: 886036, popPercent: 2.8,
    coordinates: { x: 25, y: 22 },
    diabetes: 7.0, hypertension: 6.8, cvd: 1.2, obesity: 27.5, cancer: 125,
    bedsPerCapita: 24.8, phcPerCapita: 2.4,
    inactivity: 95.0, smoking: 12.5,
    diabetesMortality: 5200, cvdMortality: 680,
    undiagnosedRisk: 'high',
    tier: 4, trend: 'stable',
  },
  hail: {
    name: 'Hail', nameAr: 'حائل',
    population: 746406, popPercent: 2.3,
    coordinates: { x: 42, y: 25 },
    diabetes: 8.0, hypertension: 7.8, cvd: 1.5, obesity: 29.0, cancer: 155,
    bedsPerCapita: 26.2, phcPerCapita: 2.6,
    inactivity: 95.8, smoking: 13.0,
    diabetesMortality: 7072, cvdMortality: 880,
    undiagnosedRisk: 'high',
    tier: 2, trend: 'worsening',
  },
  aljawf: {
    name: 'Al-Jawf', nameAr: 'الجوف',
    population: 595822, popPercent: 1.9,
    coordinates: { x: 32, y: 18 },
    diabetes: 6.8, hypertension: 6.5, cvd: 1.2, obesity: 27.0, cancer: 118,
    bedsPerCapita: 30.6, phcPerCapita: 3.2,
    inactivity: 94.8, smoking: 15.5,
    diabetesMortality: 5100, cvdMortality: 650,
    undiagnosedRisk: 'high',
    tier: 3, trend: 'stable',
  },
  najran: {
    name: 'Najran', nameAr: 'نجران',
    population: 592300, popPercent: 1.8,
    coordinates: { x: 52, y: 78 },
    diabetes: 6.1, hypertension: 6.0, cvd: 1.0, obesity: 25.5, cancer: 143,
    bedsPerCapita: 28.8, phcPerCapita: 3.0,
    inactivity: 94.0, smoking: 8.0,
    diabetesMortality: 4699, cvdMortality: 385,
    undiagnosedRisk: 'very high',
    tier: 4, trend: 'improving',
  },
  northern: {
    name: 'Northern Borders', nameAr: 'الحدود الشمالية',
    population: 373577, popPercent: 1.2,
    coordinates: { x: 48, y: 12 },
    diabetes: 6.5, hypertension: 6.2, cvd: 1.1, obesity: 26.8, cancer: 120,
    bedsPerCapita: 36.0, phcPerCapita: 3.8,
    inactivity: 94.2, smoking: 16.0,
    diabetesMortality: 4900, cvdMortality: 620,
    undiagnosedRisk: 'high',
    tier: 3, trend: 'stable',
  },
  albahah: {
    name: 'Al-Bahah', nameAr: 'الباحة',
    population: 339174, popPercent: 1.1,
    coordinates: { x: 34, y: 65 },
    diabetes: 7.4, hypertension: 8.5, cvd: 1.6, obesity: 28.8, cancer: 113,
    bedsPerCapita: 35.7, phcPerCapita: 3.92,
    inactivity: 94.5, smoking: 8.8,
    diabetesMortality: 6264, cvdMortality: 1056,
    undiagnosedRisk: 'high',
    tier: 2, trend: 'worsening',
  },
};

// National aggregates
const nationalStats = {
  population: 35300000,
  diabetesPrevalence: 16.4,
  prediabetesPrevalence: 16.3,
  obesityRate: 78.6,
  hypertensionTotal: 55.6,
  undiagnosedDiabetes: 58,
  undiagnosedHypertension: 65,
  physicalInactivity: 96.1,
  lifeExpectancy: 78.8,
  healthyLifeExpectancy: 65,
  cvdDeathPercent: 28,
  vision2030LifeExpTarget: 80,
  uhcIndex: 83,
  bedsPerCapita: 23.4,
  targetBedsPerCapita: 29,
};

// Vision 2030 KPIs
const vision2030KPIs = [
  { name: 'Life Expectancy', current: 78.8, target: 80, unit: 'years', status: 'on-track' },
  { name: 'UHC Index', current: 83, target: 90, unit: 'points', status: 'on-track' },
  { name: 'Physical Activity', current: 58.5, target: 65, unit: '%', status: 'at-risk' },
  { name: 'Obesity Reduction', current: -2, target: -10, unit: '% change', status: 'off-track' },
  { name: 'Digital Health', current: 80, target: 100, unit: '%', status: 'on-track' },
  { name: 'Healthcare Coverage', current: 96.4, target: 100, unit: '%', status: 'on-track' },
];

// ============================================================================
// DESIGN SYSTEM
// ============================================================================

const colors = {
  bg: {
    primary: '#0A0F1A',
    secondary: '#0F1729',
    tertiary: '#162032',
    card: 'rgba(22, 32, 50, 0.8)',
    cardHover: 'rgba(30, 45, 70, 0.9)',
  },
  accent: {
    primary: '#00E5BF',
    primaryDim: 'rgba(0, 229, 191, 0.15)',
    secondary: '#3B82F6',
    secondaryDim: 'rgba(59, 130, 246, 0.15)',
    warning: '#F59E0B',
    warningDim: 'rgba(245, 158, 11, 0.15)',
    danger: '#EF4444',
    dangerDim: 'rgba(239, 68, 68, 0.15)',
    success: '#10B981',
  },
  text: {
    primary: '#F1F5F9',
    secondary: '#94A3B8',
    muted: '#64748B',
  },
  border: 'rgba(148, 163, 184, 0.1)',
  glow: '0 0 40px rgba(0, 229, 191, 0.15)',
};

const tierColors = {
  1: colors.accent.danger,
  2: colors.accent.warning,
  3: colors.accent.secondary,
  4: colors.accent.success,
};

const tierLabels = {
  1: 'Critical',
  2: 'High Priority',
  3: 'Moderate',
  4: 'Monitor',
};

// ============================================================================
// UTILITY COMPONENTS
// ============================================================================

const GlowOrb = ({ color, size = 300, top, left, right, bottom }) => (
  <div style={{
    position: 'absolute',
    width: size,
    height: size,
    background: `radial-gradient(circle, ${color}20 0%, transparent 70%)`,
    borderRadius: '50%',
    filter: 'blur(60px)',
    top, left, right, bottom,
    pointerEvents: 'none',
  }} />
);

const StatCard = ({ label, value, subtext, trend, color = colors.accent.primary, small }) => (
  <div style={{
    background: colors.bg.card,
    borderRadius: 12,
    padding: small ? '14px 16px' : '20px 24px',
    border: `1px solid ${colors.border}`,
    position: 'relative',
    overflow: 'hidden',
  }}>
    <div style={{
      position: 'absolute',
      top: 0,
      left: 0,
      width: 3,
      height: '100%',
      background: color,
    }} />
    <div style={{
      fontSize: small ? 10 : 11,
      color: colors.text.muted,
      textTransform: 'uppercase',
      letterSpacing: '0.5px',
      marginBottom: 6,
    }}>{label}</div>
    <div style={{
      fontSize: small ? 24 : 32,
      fontWeight: 700,
      color: color,
      display: 'flex',
      alignItems: 'baseline',
      gap: 8,
    }}>
      {value}
      {trend && (
        <span style={{
          fontSize: 12,
          color: trend > 0 ? colors.accent.success : colors.accent.danger,
        }}>
          {trend > 0 ? '↑' : '↓'} {Math.abs(trend)}%
        </span>
      )}
    </div>
    {subtext && (
      <div style={{
        fontSize: small ? 11 : 12,
        color: colors.text.secondary,
        marginTop: 4,
      }}>{subtext}</div>
    )}
  </div>
);

const ProgressBar = ({ value, max, color, height = 8, showLabel = true }) => {
  const percent = (value / max) * 100;
  return (
    <div>
      <div style={{
        height,
        background: colors.bg.tertiary,
        borderRadius: height / 2,
        overflow: 'hidden',
      }}>
        <div style={{
          width: `${Math.min(percent, 100)}%`,
          height: '100%',
          background: `linear-gradient(90deg, ${color}, ${color}CC)`,
          borderRadius: height / 2,
          transition: 'width 0.5s ease',
        }} />
      </div>
      {showLabel && (
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          marginTop: 4,
          fontSize: 10,
          color: colors.text.muted,
        }}>
          <span>{value}</span>
          <span>Target: {max}</span>
        </div>
      )}
    </div>
  );
};

// ============================================================================
// NATIONAL HEALTH SCORE COMPONENT
// ============================================================================

const NationalHealthScore = ({ score = 62 }) => {
  const circumference = 2 * Math.PI * 85;
  const offset = circumference - (score / 100) * circumference;
  
  return (
    <div style={{
      background: colors.bg.card,
      borderRadius: 16,
      padding: 24,
      border: `1px solid ${colors.border}`,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      position: 'relative',
    }}>
      <div style={{
        fontSize: 11,
        color: colors.text.muted,
        textTransform: 'uppercase',
        letterSpacing: '1px',
        marginBottom: 16,
      }}>National Health Index</div>
      
      <svg width="200" height="200" style={{ transform: 'rotate(-90deg)' }}>
        <circle
          cx="100" cy="100" r="85"
          fill="none"
          stroke={colors.bg.tertiary}
          strokeWidth="12"
        />
        <circle
          cx="100" cy="100" r="85"
          fill="none"
          stroke={score >= 70 ? colors.accent.success : score >= 50 ? colors.accent.warning : colors.accent.danger}
          strokeWidth="12"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          style={{ transition: 'stroke-dashoffset 1s ease' }}
        />
        <defs>
          <filter id="glow">
            <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
            <feMerge>
              <feMergeNode in="coloredBlur"/>
              <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
        </defs>
      </svg>
      
      <div style={{
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        textAlign: 'center',
        marginTop: 12,
      }}>
        <div style={{
          fontSize: 48,
          fontWeight: 700,
          color: colors.text.primary,
        }}>{score}</div>
        <div style={{
          fontSize: 12,
          color: colors.text.secondary,
        }}>of 100</div>
      </div>
      
      <div style={{
        display: 'flex',
        gap: 16,
        marginTop: 20,
        fontSize: 11,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <div style={{ width: 8, height: 8, borderRadius: 4, background: colors.accent.success }} />
          <span style={{ color: colors.text.muted }}>Good (70+)</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <div style={{ width: 8, height: 8, borderRadius: 4, background: colors.accent.warning }} />
          <span style={{ color: colors.text.muted }}>Fair (50-69)</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <div style={{ width: 8, height: 8, borderRadius: 4, background: colors.accent.danger }} />
          <span style={{ color: colors.text.muted }}>Critical (&lt;50)</span>
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// POPULATION PYRAMID COMPONENT
// ============================================================================

const PopulationPyramid = () => {
  const ageGroups = [
    { label: '80+', healthy: 0.3, atRisk: 0.15, ncd: 0.05 },
    { label: '70-79', healthy: 1.2, atRisk: 0.8, ncd: 0.4 },
    { label: '60-69', healthy: 2.5, atRisk: 1.8, ncd: 1.2 },
    { label: '50-59', healthy: 4.0, atRisk: 2.5, ncd: 1.5 },
    { label: '40-49', healthy: 5.5, atRisk: 2.0, ncd: 0.8 },
    { label: '30-39', healthy: 7.0, atRisk: 1.2, ncd: 0.3 },
    { label: '20-29', healthy: 8.5, atRisk: 0.5, ncd: 0.1 },
    { label: '10-19', healthy: 6.5, atRisk: 0.2, ncd: 0.05 },
    { label: '0-9', healthy: 5.8, atRisk: 0.1, ncd: 0.02 },
  ];
  
  const maxWidth = 12;
  
  return (
    <div style={{
      background: colors.bg.card,
      borderRadius: 16,
      padding: 24,
      border: `1px solid ${colors.border}`,
    }}>
      <div style={{
        fontSize: 11,
        color: colors.text.muted,
        textTransform: 'uppercase',
        letterSpacing: '1px',
        marginBottom: 20,
      }}>Population by Age & Health Status</div>
      
      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        {ageGroups.map((group, i) => {
          const total = group.healthy + group.atRisk + group.ncd;
          return (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{
                width: 45,
                fontSize: 11,
                color: colors.text.secondary,
                textAlign: 'right',
              }}>{group.label}</div>
              <div style={{
                flex: 1,
                height: 18,
                display: 'flex',
                borderRadius: 4,
                overflow: 'hidden',
              }}>
                <div style={{
                  width: `${(group.healthy / maxWidth) * 100}%`,
                  background: colors.accent.success,
                  transition: 'width 0.5s ease',
                }} />
                <div style={{
                  width: `${(group.atRisk / maxWidth) * 100}%`,
                  background: colors.accent.warning,
                  transition: 'width 0.5s ease',
                }} />
                <div style={{
                  width: `${(group.ncd / maxWidth) * 100}%`,
                  background: colors.accent.danger,
                  transition: 'width 0.5s ease',
                }} />
              </div>
              <div style={{
                width: 40,
                fontSize: 10,
                color: colors.text.muted,
              }}>{total.toFixed(1)}M</div>
            </div>
          );
        })}
      </div>
      
      <div style={{
        display: 'flex',
        gap: 20,
        marginTop: 20,
        paddingTop: 16,
        borderTop: `1px solid ${colors.border}`,
        fontSize: 11,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <div style={{ width: 12, height: 12, borderRadius: 3, background: colors.accent.success }} />
          <span style={{ color: colors.text.muted }}>Healthy</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <div style={{ width: 12, height: 12, borderRadius: 3, background: colors.accent.warning }} />
          <span style={{ color: colors.text.muted }}>At Risk</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <div style={{ width: 12, height: 12, borderRadius: 3, background: colors.accent.danger }} />
          <span style={{ color: colors.text.muted }}>Diagnosed NCD</span>
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// AGING TRAJECTORY GAP VISUALIZATION
// ============================================================================

const AgingTrajectoryGap = () => {
  const generateCurve = (start, end, power) => {
    const points = [];
    for (let age = 30; age <= 90; age += 5) {
      const t = (age - 30) / 60;
      const value = start - (start - end) * Math.pow(t, power);
      points.push({ age, value });
    }
    return points;
  };
  
  const populationCurve = generateCurve(95, 35, 1.4);
  const superAgerCurve = generateCurve(95, 72, 0.8);
  
  const width = 400;
  const height = 200;
  const padding = { top: 20, right: 20, bottom: 30, left: 40 };
  
  const xScale = (age) => padding.left + ((age - 30) / 60) * (width - padding.left - padding.right);
  const yScale = (val) => padding.top + (1 - val / 100) * (height - padding.top - padding.bottom);
  
  const pathD = (points) => points.map((p, i) => 
    `${i === 0 ? 'M' : 'L'} ${xScale(p.age)} ${yScale(p.value)}`
  ).join(' ');
  
  const areaD = () => {
    const top = superAgerCurve.map(p => `${xScale(p.age)},${yScale(p.value)}`).join(' ');
    const bottom = [...populationCurve].reverse().map(p => `${xScale(p.age)},${yScale(p.value)}`).join(' ');
    return `M ${top} L ${bottom} Z`;
  };
  
  // Calculate gap at age 65
  const popAt65 = populationCurve.find(p => p.age === 65)?.value || 0;
  const saAt65 = superAgerCurve.find(p => p.age === 65)?.value || 0;
  const gap = saAt65 - popAt65;
  
  return (
    <div style={{
      background: colors.bg.card,
      borderRadius: 16,
      padding: 24,
      border: `1px solid ${colors.border}`,
      position: 'relative',
    }}>
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        marginBottom: 16,
      }}>
        <div>
          <div style={{
            fontSize: 11,
            color: colors.text.muted,
            textTransform: 'uppercase',
            letterSpacing: '1px',
          }}>The Intervention Opportunity</div>
          <div style={{
            fontSize: 14,
            color: colors.text.secondary,
            marginTop: 4,
          }}>Population trajectory vs optimal aging</div>
        </div>
        <div style={{
          background: colors.accent.primaryDim,
          padding: '8px 14px',
          borderRadius: 8,
          border: `1px solid ${colors.accent.primary}30`,
        }}>
          <div style={{ fontSize: 10, color: colors.accent.primary }}>GAP AT AGE 65</div>
          <div style={{ fontSize: 22, fontWeight: 700, color: colors.accent.primary }}>+{gap.toFixed(0)}%</div>
        </div>
      </div>
      
      <svg width={width} height={height}>
        {/* Grid */}
        {[25, 50, 75, 100].map(v => (
          <g key={v}>
            <line
              x1={padding.left} y1={yScale(v)}
              x2={width - padding.right} y2={yScale(v)}
              stroke={colors.border} strokeDasharray="2,4"
            />
            <text x={padding.left - 8} y={yScale(v) + 4} fill={colors.text.muted} fontSize="9" textAnchor="end">
              {v}
            </text>
          </g>
        ))}
        
        {/* X axis */}
        {[30, 45, 60, 75, 90].map(age => (
          <text key={age} x={xScale(age)} y={height - 8} fill={colors.text.muted} fontSize="9" textAnchor="middle">
            {age}
          </text>
        ))}
        
        {/* Gap area */}
        <path d={areaD()} fill={colors.accent.primary} opacity="0.15" />
        
        {/* Curves */}
        <path d={pathD(populationCurve)} fill="none" stroke={colors.accent.danger} strokeWidth="2.5" />
        <path d={pathD(superAgerCurve)} fill="none" stroke={colors.accent.primary} strokeWidth="2.5" />
        
        {/* Labels */}
        <text x={width - 25} y={yScale(72) - 8} fill={colors.accent.primary} fontSize="10" textAnchor="end">Super Ager</text>
        <text x={width - 25} y={yScale(35) + 14} fill={colors.accent.danger} fontSize="10" textAnchor="end">KSA Population</text>
      </svg>
      
      <div style={{
        marginTop: 16,
        padding: '12px 16px',
        background: colors.bg.tertiary,
        borderRadius: 8,
        fontSize: 12,
        color: colors.text.secondary,
        lineHeight: 1.6,
      }}>
        <strong style={{ color: colors.accent.primary }}>The shaded area represents addressable health optimization.</strong> Closing this gap through predictive intervention could add 10+ healthy life years for millions of Saudis.
      </div>
    </div>
  );
};

// ============================================================================
// PROVINCE MAP COMPONENT
// ============================================================================

const ProvinceMap = ({ onProvinceClick, selectedProvince }) => {
  return (
    <div style={{
      background: colors.bg.card,
      borderRadius: 16,
      padding: 24,
      border: `1px solid ${colors.border}`,
    }}>
      <div style={{
        fontSize: 11,
        color: colors.text.muted,
        textTransform: 'uppercase',
        letterSpacing: '1px',
        marginBottom: 20,
      }}>Provincial Health Risk Map</div>
      
      <div style={{
        position: 'relative',
        width: '100%',
        height: 300,
        background: colors.bg.tertiary,
        borderRadius: 12,
        overflow: 'hidden',
      }}>
        {/* Simplified KSA outline */}
        <svg viewBox="0 0 100 100" style={{ width: '100%', height: '100%' }}>
          <path
            d="M 15 15 L 35 10 L 55 8 L 75 15 L 85 25 L 90 40 L 85 55 L 75 70 L 60 80 L 45 85 L 30 82 L 20 70 L 15 55 L 12 40 Z"
            fill={colors.bg.secondary}
            stroke={colors.border}
            strokeWidth="0.5"
          />
          
          {/* Province markers */}
          {Object.entries(provinceData).map(([key, province]) => {
            const isSelected = selectedProvince === key;
            const tierColor = tierColors[province.tier];
            
            return (
              <g key={key} style={{ cursor: 'pointer' }} onClick={() => onProvinceClick(key)}>
                <circle
                  cx={province.coordinates.x}
                  cy={province.coordinates.y}
                  r={isSelected ? 6 : 4 + (province.population / 3000000)}
                  fill={tierColor}
                  opacity={isSelected ? 1 : 0.8}
                  stroke={isSelected ? colors.text.primary : 'none'}
                  strokeWidth="2"
                />
                {isSelected && (
                  <circle
                    cx={province.coordinates.x}
                    cy={province.coordinates.y}
                    r={10}
                    fill="none"
                    stroke={tierColor}
                    strokeWidth="1"
                    opacity="0.5"
                  />
                )}
              </g>
            );
          })}
        </svg>
        
        {/* Province tooltip */}
        {selectedProvince && (
          <div style={{
            position: 'absolute',
            bottom: 12,
            left: 12,
            right: 12,
            background: colors.bg.primary,
            borderRadius: 8,
            padding: 12,
            border: `1px solid ${colors.border}`,
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <div style={{ fontSize: 14, fontWeight: 600, color: colors.text.primary }}>
                  {provinceData[selectedProvince].name}
                </div>
                <div style={{ fontSize: 11, color: colors.text.muted }}>
                  {(provinceData[selectedProvince].population / 1000000).toFixed(1)}M population
                </div>
              </div>
              <div style={{
                padding: '4px 10px',
                borderRadius: 6,
                background: tierColors[provinceData[selectedProvince].tier] + '20',
                color: tierColors[provinceData[selectedProvince].tier],
                fontSize: 11,
                fontWeight: 600,
              }}>
                {tierLabels[provinceData[selectedProvince].tier]}
              </div>
            </div>
          </div>
        )}
      </div>
      
      {/* Legend */}
      <div style={{
        display: 'flex',
        gap: 16,
        marginTop: 16,
        fontSize: 11,
        flexWrap: 'wrap',
      }}>
        {Object.entries(tierLabels).map(([tier, label]) => (
          <div key={tier} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{
              width: 10,
              height: 10,
              borderRadius: 5,
              background: tierColors[tier],
            }} />
            <span style={{ color: colors.text.muted }}>{label}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

// ============================================================================
// VISION 2030 KPI TRACKER
// ============================================================================

const Vision2030Tracker = () => {
  const statusColors = {
    'on-track': colors.accent.success,
    'at-risk': colors.accent.warning,
    'off-track': colors.accent.danger,
  };
  
  return (
    <div style={{
      background: colors.bg.card,
      borderRadius: 16,
      padding: 24,
      border: `1px solid ${colors.border}`,
    }}>
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 20,
      }}>
        <div style={{
          fontSize: 11,
          color: colors.text.muted,
          textTransform: 'uppercase',
          letterSpacing: '1px',
        }}>Vision 2030 Health KPIs</div>
        <div style={{
          background: colors.accent.primaryDim,
          padding: '4px 10px',
          borderRadius: 6,
          fontSize: 10,
          color: colors.accent.primary,
        }}>LIVE TRACKING</div>
      </div>
      
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        {vision2030KPIs.map((kpi, i) => (
          <div key={i}>
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: 6,
            }}>
              <span style={{ fontSize: 13, color: colors.text.primary }}>{kpi.name}</span>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ fontSize: 13, fontWeight: 600, color: statusColors[kpi.status] }}>
                  {kpi.current}{kpi.unit === '%' || kpi.unit === '% change' ? '%' : ''} 
                </span>
                <span style={{
                  fontSize: 9,
                  padding: '2px 6px',
                  borderRadius: 4,
                  background: statusColors[kpi.status] + '20',
                  color: statusColors[kpi.status],
                  textTransform: 'uppercase',
                }}>
                  {kpi.status.replace('-', ' ')}
                </span>
              </div>
            </div>
            <ProgressBar
              value={kpi.current}
              max={kpi.target}
              color={statusColors[kpi.status]}
              height={6}
              showLabel={false}
            />
          </div>
        ))}
      </div>
    </div>
  );
};

// ============================================================================
// PROVINCIAL COMPARISON TABLE
// ============================================================================

const ProvinceTable = ({ onProvinceClick }) => {
  const [sortKey, setSortKey] = useState('tier');
  const [sortDir, setSortDir] = useState('asc');
  
  const sortedProvinces = Object.entries(provinceData)
    .sort(([, a], [, b]) => {
      const aVal = a[sortKey];
      const bVal = b[sortKey];
      return sortDir === 'asc' ? aVal - bVal : bVal - aVal;
    });
  
  const handleSort = (key) => {
    if (sortKey === key) {
      setSortDir(sortDir === 'asc' ? 'desc' : 'asc');
    } else {
      setSortKey(key);
      setSortDir('desc');
    }
  };
  
  const columns = [
    { key: 'name', label: 'Province', width: '15%' },
    { key: 'population', label: 'Population', width: '12%' },
    { key: 'diabetes', label: 'Diabetes %', width: '10%' },
    { key: 'hypertension', label: 'HTN %', width: '10%' },
    { key: 'obesity', label: 'Obesity %', width: '10%' },
    { key: 'bedsPerCapita', label: 'Beds/10K', width: '10%' },
    { key: 'inactivity', label: 'Inactive %', width: '10%' },
    { key: 'tier', label: 'Priority', width: '12%' },
    { key: 'trend', label: 'Trend', width: '11%' },
  ];
  
  return (
    <div style={{
      background: colors.bg.card,
      borderRadius: 16,
      border: `1px solid ${colors.border}`,
      overflow: 'hidden',
    }}>
      <div style={{
        padding: '16px 24px',
        borderBottom: `1px solid ${colors.border}`,
      }}>
        <div style={{
          fontSize: 11,
          color: colors.text.muted,
          textTransform: 'uppercase',
          letterSpacing: '1px',
        }}>Provincial Health Comparison</div>
      </div>
      
      <div style={{ overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 800 }}>
          <thead>
            <tr style={{ background: colors.bg.tertiary }}>
              {columns.map(col => (
                <th
                  key={col.key}
                  onClick={() => col.key !== 'name' && handleSort(col.key)}
                  style={{
                    padding: '12px 16px',
                    textAlign: 'left',
                    fontSize: 11,
                    fontWeight: 600,
                    color: colors.text.secondary,
                    cursor: col.key !== 'name' ? 'pointer' : 'default',
                    width: col.width,
                    whiteSpace: 'nowrap',
                  }}
                >
                  {col.label}
                  {sortKey === col.key && (
                    <span style={{ marginLeft: 4 }}>{sortDir === 'asc' ? '↑' : '↓'}</span>
                  )}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {sortedProvinces.map(([key, p]) => (
              <tr
                key={key}
                onClick={() => onProvinceClick(key)}
                style={{
                  borderBottom: `1px solid ${colors.border}`,
                  cursor: 'pointer',
                  transition: 'background 0.2s',
                }}
                onMouseEnter={(e) => e.currentTarget.style.background = colors.bg.cardHover}
                onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
              >
                <td style={{ padding: '12px 16px' }}>
                  <div style={{ fontWeight: 500, color: colors.text.primary }}>{p.name}</div>
                  <div style={{ fontSize: 10, color: colors.text.muted }}>{p.nameAr}</div>
                </td>
                <td style={{ padding: '12px 16px', color: colors.text.secondary, fontSize: 13 }}>
                  {(p.population / 1000000).toFixed(1)}M
                </td>
                <td style={{ padding: '12px 16px' }}>
                  <span style={{
                    color: p.diabetes > 8 ? colors.accent.danger : p.diabetes > 7 ? colors.accent.warning : colors.text.secondary,
                    fontWeight: p.diabetes > 8 ? 600 : 400,
                  }}>{p.diabetes}%</span>
                </td>
                <td style={{ padding: '12px 16px' }}>
                  <span style={{
                    color: p.hypertension > 8 ? colors.accent.danger : colors.text.secondary,
                  }}>{p.hypertension}%</span>
                </td>
                <td style={{ padding: '12px 16px', color: colors.text.secondary }}>{p.obesity}%</td>
                <td style={{ padding: '12px 16px' }}>
                  <span style={{
                    color: p.bedsPerCapita < 23 ? colors.accent.danger : colors.text.secondary,
                  }}>{p.bedsPerCapita}</span>
                </td>
                <td style={{ padding: '12px 16px', color: colors.text.muted }}>{p.inactivity}%</td>
                <td style={{ padding: '12px 16px' }}>
                  <span style={{
                    padding: '4px 10px',
                    borderRadius: 6,
                    fontSize: 11,
                    fontWeight: 500,
                    background: tierColors[p.tier] + '20',
                    color: tierColors[p.tier],
                  }}>
                    {tierLabels[p.tier]}
                  </span>
                </td>
                <td style={{ padding: '12px 16px' }}>
                  <span style={{
                    color: p.trend === 'improving' ? colors.accent.success 
                         : p.trend === 'worsening' ? colors.accent.danger 
                         : colors.text.muted,
                  }}>
                    {p.trend === 'improving' ? '↑ Improving' 
                     : p.trend === 'worsening' ? '↓ Worsening' 
                     : '→ Stable'}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// ============================================================================
// QUADRANT ANALYSIS
// ============================================================================

const QuadrantAnalysis = ({ onProvinceClick }) => {
  const width = 500;
  const height = 400;
  const padding = { top: 40, right: 40, bottom: 60, left: 60 };
  
  // Calculate burden score (higher = worse)
  const getBurdenScore = (p) => (p.diabetes + p.hypertension + p.cvd * 10 + p.obesity / 3) / 4;
  
  // Map trend to numeric
  const getTrendScore = (trend) => trend === 'improving' ? 1 : trend === 'worsening' ? -1 : 0;
  
  const xScale = (burden) => {
    const min = 5, max = 15;
    return padding.left + ((burden - min) / (max - min)) * (width - padding.left - padding.right);
  };
  
  const yScale = (trend) => {
    return padding.top + ((1 - trend) / 2) * (height - padding.top - padding.bottom);
  };
  
  const midX = (width - padding.left - padding.right) / 2 + padding.left;
  const midY = (height - padding.top - padding.bottom) / 2 + padding.top;
  
  return (
    <div style={{
      background: colors.bg.card,
      borderRadius: 16,
      padding: 24,
      border: `1px solid ${colors.border}`,
    }}>
      <div style={{
        fontSize: 11,
        color: colors.text.muted,
        textTransform: 'uppercase',
        letterSpacing: '1px',
        marginBottom: 20,
      }}>Strategic Quadrant Analysis</div>
      
      <svg width={width} height={height}>
        {/* Quadrant backgrounds */}
        <rect x={midX} y={padding.top} width={width - midX - padding.right} height={midY - padding.top}
              fill={colors.accent.warningDim} opacity="0.3" />
        <rect x={padding.left} y={padding.top} width={midX - padding.left} height={midY - padding.top}
              fill={colors.accent.secondaryDim} opacity="0.3" />
        <rect x={padding.left} y={midY} width={midX - padding.left} height={height - midY - padding.bottom}
              fill={colors.accent.primaryDim} opacity="0.3" />
        <rect x={midX} y={midY} width={width - midX - padding.right} height={height - midY - padding.bottom}
              fill={colors.accent.dangerDim} opacity="0.3" />
        
        {/* Axes */}
        <line x1={padding.left} y1={midY} x2={width - padding.right} y2={midY}
              stroke={colors.border} strokeDasharray="4,4" />
        <line x1={midX} y1={padding.top} x2={midX} y2={height - padding.bottom}
              stroke={colors.border} strokeDasharray="4,4" />
        
        {/* Quadrant labels */}
        <text x={padding.left + 10} y={padding.top + 20} fill={colors.accent.secondary} fontSize="11" fontWeight="600">
          WATCH
        </text>
        <text x={width - padding.right - 60} y={padding.top + 20} fill={colors.accent.warning} fontSize="11" fontWeight="600">
          PROGRESS
        </text>
        <text x={padding.left + 10} y={height - padding.bottom - 10} fill={colors.accent.primary} fontSize="11" fontWeight="600">
          MODEL
        </text>
        <text x={width - padding.right - 50} y={height - padding.bottom - 10} fill={colors.accent.danger} fontSize="11" fontWeight="600">
          CRISIS
        </text>
        
        {/* Province bubbles */}
        {Object.entries(provinceData).map(([key, p]) => {
          const burden = getBurdenScore(p);
          const trend = getTrendScore(p.trend);
          const size = Math.sqrt(p.population / 1000000) * 8;
          
          return (
            <g key={key} style={{ cursor: 'pointer' }} onClick={() => onProvinceClick(key)}>
              <circle
                cx={xScale(burden)}
                cy={yScale(trend)}
                r={size}
                fill={tierColors[p.tier]}
                opacity="0.7"
                stroke={colors.text.primary}
                strokeWidth="1"
              />
              <text
                x={xScale(burden)}
                y={yScale(trend) + size + 12}
                fill={colors.text.secondary}
                fontSize="9"
                textAnchor="middle"
              >
                {p.name.split(' ')[0]}
              </text>
            </g>
          );
        })}
        
        {/* Axis labels */}
        <text x={width / 2} y={height - 15} fill={colors.text.secondary} fontSize="11" textAnchor="middle">
          Health Burden Score →
        </text>
        <text
          transform={`translate(15, ${height / 2}) rotate(-90)`}
          fill={colors.text.secondary}
          fontSize="11"
          textAnchor="middle"
        >
          ← Worsening | Improving →
        </text>
      </svg>
      
      <div style={{
        marginTop: 16,
        padding: 12,
        background: colors.bg.tertiary,
        borderRadius: 8,
        fontSize: 11,
        color: colors.text.secondary,
      }}>
        Bubble size = population. <strong style={{ color: colors.accent.danger }}>Crisis</strong> quadrant (high burden + worsening) requires immediate intervention. 
        <strong style={{ color: colors.accent.primary }}> Model</strong> provinces show protective factors worth studying.
      </div>
    </div>
  );
};

// ============================================================================
// MAIN DASHBOARD COMPONENT
// ============================================================================

export default function KSAHealthDashboard() {
  const [currentView, setCurrentView] = useState('national');
  const [selectedProvince, setSelectedProvince] = useState(null);
  
  const handleProvinceClick = (key) => {
    setSelectedProvince(key);
    if (currentView === 'national') {
      setCurrentView('provincial');
    }
  };
  
  return (
    <div style={{
      minHeight: '100vh',
      background: colors.bg.primary,
      color: colors.text.primary,
      fontFamily: '"SF Pro Display", -apple-system, BlinkMacSystemFont, sans-serif',
      position: 'relative',
      overflow: 'hidden',
    }}>
      {/* Background effects */}
      <GlowOrb color={colors.accent.primary} size={400} top="-100px" right="-100px" />
      <GlowOrb color={colors.accent.secondary} size={300} bottom="20%" left="-50px" />
      
      {/* Header */}
      <header style={{
        padding: '20px 32px',
        borderBottom: `1px solid ${colors.border}`,
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        position: 'relative',
        zIndex: 10,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <div style={{
            background: `linear-gradient(135deg, ${colors.accent.primary}, ${colors.accent.secondary})`,
            padding: '8px 14px',
            borderRadius: 8,
            fontSize: 12,
            fontWeight: 700,
            letterSpacing: '1px',
          }}>
            NURAXI VITRUVIA
          </div>
          <div>
            <h1 style={{ fontSize: 20, fontWeight: 600, margin: 0 }}>
              Kingdom of Saudi Arabia
            </h1>
            <p style={{ fontSize: 12, color: colors.text.muted, margin: 0 }}>
              National Health Intelligence Dashboard
            </p>
          </div>
        </div>
        
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{
            padding: '6px 12px',
            background: colors.accent.primaryDim,
            borderRadius: 6,
            fontSize: 11,
            color: colors.accent.primary,
          }}>
            Vision 2030 Aligned
          </div>
          <div style={{
            padding: '6px 12px',
            background: colors.bg.tertiary,
            borderRadius: 6,
            fontSize: 11,
            color: colors.text.secondary,
          }}>
            عربي | EN
          </div>
        </div>
      </header>
      
      {/* Navigation */}
      <nav style={{
        padding: '12px 32px',
        borderBottom: `1px solid ${colors.border}`,
        display: 'flex',
        gap: 8,
        position: 'relative',
        zIndex: 10,
      }}>
        {[
          { id: 'national', label: 'National Overview', icon: '🏛️' },
          { id: 'provincial', label: 'Provincial Comparison', icon: '📊' },
          { id: 'disease', label: 'Disease Analysis', icon: '🩺' },
          { id: 'intervention', label: 'Intervention Modeling', icon: '🎯' },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setCurrentView(tab.id)}
            style={{
              padding: '10px 18px',
              background: currentView === tab.id ? colors.accent.primary : 'transparent',
              color: currentView === tab.id ? colors.bg.primary : colors.text.secondary,
              border: `1px solid ${currentView === tab.id ? colors.accent.primary : colors.border}`,
              borderRadius: 8,
              fontSize: 13,
              fontWeight: 500,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              transition: 'all 0.2s',
            }}
          >
            <span>{tab.icon}</span>
            {tab.label}
          </button>
        ))}
      </nav>
      
      {/* Main content */}
      <main style={{
        padding: 32,
        position: 'relative',
        zIndex: 10,
      }}>
        {currentView === 'national' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
            {/* Top stats row */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(5, 1fr)',
              gap: 16,
            }}>
              <StatCard
                label="Total Population"
                value="35.3M"
                subtext="2024 estimate"
                color={colors.accent.primary}
              />
              <StatCard
                label="Diabetes Prevalence"
                value="16.4%"
                subtext="~5.8M affected"
                color={colors.accent.danger}
                trend={-2}
              />
              <StatCard
                label="Undiagnosed NCDs"
                value="58%"
                subtext="Hidden burden"
                color={colors.accent.warning}
              />
              <StatCard
                label="Life Expectancy"
                value="78.8yr"
                subtext="Target: 80yr"
                color={colors.accent.success}
                trend={3}
              />
              <StatCard
                label="Healthy Life Years"
                value="65yr"
                subtext="13.8yr gap"
                color={colors.accent.secondary}
              />
            </div>
            
            {/* Main content grid */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: '280px 1fr 1fr',
              gap: 24,
            }}>
              <NationalHealthScore score={62} />
              <AgingTrajectoryGap />
              <ProvinceMap onProvinceClick={handleProvinceClick} selectedProvince={selectedProvince} />
            </div>
            
            {/* Bottom row */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              gap: 24,
            }}>
              <PopulationPyramid />
              <Vision2030Tracker />
            </div>
          </div>
        )}
        
        {currentView === 'provincial' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
            {/* Province summary stats */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(4, 1fr)',
              gap: 16,
            }}>
              <StatCard
                label="Critical Provinces"
                value="3"
                subtext="Makkah, Jazan, Eastern"
                color={colors.accent.danger}
                small
              />
              <StatCard
                label="High Priority"
                value="3"
                subtext="Riyadh, Hail, Al-Bahah"
                color={colors.accent.warning}
                small
              />
              <StatCard
                label="Infrastructure Gap"
                value="17K"
                subtext="Additional beds needed"
                color={colors.accent.secondary}
                small
              />
              <StatCard
                label="Model Province"
                value="Najran"
                subtext="Lowest NCD burden"
                color={colors.accent.success}
                small
              />
            </div>
            
            {/* Quadrant and map */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: '1fr 350px',
              gap: 24,
            }}>
              <QuadrantAnalysis onProvinceClick={handleProvinceClick} />
              <ProvinceMap onProvinceClick={handleProvinceClick} selectedProvince={selectedProvince} />
            </div>
            
            {/* Province table */}
            <ProvinceTable onProvinceClick={handleProvinceClick} />
          </div>
        )}
        
        {currentView === 'disease' && (
          <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            height: 400,
            background: colors.bg.card,
            borderRadius: 16,
            border: `1px solid ${colors.border}`,
          }}>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 48, marginBottom: 16 }}>🩺</div>
              <div style={{ fontSize: 18, color: colors.text.primary, marginBottom: 8 }}>
                Disease Analysis Module
              </div>
              <div style={{ fontSize: 13, color: colors.text.muted }}>
                Diabetes, CVD, Obesity, Cancer, Mental Health deep-dives
              </div>
              <div style={{
                marginTop: 16,
                padding: '8px 16px',
                background: colors.accent.primaryDim,
                borderRadius: 8,
                fontSize: 12,
                color: colors.accent.primary,
                display: 'inline-block',
              }}>
                Coming in next iteration
              </div>
            </div>
          </div>
        )}
        
        {currentView === 'intervention' && (
          <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            height: 400,
            background: colors.bg.card,
            borderRadius: 16,
            border: `1px solid ${colors.border}`,
          }}>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 48, marginBottom: 16 }}>🎯</div>
              <div style={{ fontSize: 18, color: colors.text.primary, marginBottom: 8 }}>
                Intervention Modeling Engine
              </div>
              <div style={{ fontSize: 13, color: colors.text.muted }}>
                Scenario modeling, cost-benefit analysis, trajectory projections
              </div>
              <div style={{
                marginTop: 16,
                padding: '8px 16px',
                background: colors.accent.primaryDim,
                borderRadius: 8,
                fontSize: 12,
                color: colors.accent.primary,
                display: 'inline-block',
              }}>
                Powered by Vitruvia AI
              </div>
            </div>
          </div>
        )}
      </main>
      
      {/* Footer */}
      <footer style={{
        padding: '16px 32px',
        borderTop: `1px solid ${colors.border}`,
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        fontSize: 11,
        color: colors.text.muted,
        position: 'relative',
        zIndex: 10,
      }}>
        <div>
          Data sources: GASTAT Census 2022, Saudi Health Interview Survey, MOH Statistical Yearbook, IHME GBD Study
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <span>Sovereign Data • In-Kingdom Processing</span>
          <span style={{ color: colors.accent.primary }}>●</span>
          <span>Real-time sync available</span>
        </div>
      </footer>
    </div>
  );
}
