import React, { useState } from 'react';

// Nuraxi brand colors
const colors = {
  primary: '#0D1B2A',
  secondary: '#1B3A4B',
  accent: '#00D4AA',
  accentDim: 'rgba(0, 212, 170, 0.3)',
  warning: '#FF6B6B',
  warningDim: 'rgba(255, 107, 107, 0.2)',
  gold: '#FFD700',
  text: '#E0E1DD',
  textMuted: '#778DA9',
  background: '#0D1B2A',
  cardBg: 'rgba(27, 58, 75, 0.6)',
  gridLine: 'rgba(119, 141, 169, 0.2)',
};

// Generate curve data points
const generateCurve = (startValue, endValue, curveType = 'linear', noise = 0) => {
  const points = [];
  for (let age = 30; age <= 100; age += 5) {
    const t = (age - 30) / 70;
    let value;
    
    if (curveType === 'exponential') {
      // Steeper decline for population
      value = startValue - (startValue - endValue) * Math.pow(t, 1.5);
    } else if (curveType === 'superager') {
      // Flatter curve for super agers
      value = startValue - (startValue - endValue) * Math.pow(t, 0.7);
    } else {
      value = startValue - (startValue - endValue) * t;
    }
    
    // Add some noise for realism
    value += (Math.random() - 0.5) * noise;
    points.push({ age, value: Math.max(0, Math.min(100, value)) });
  }
  return points;
};

// Domain data
const domains = {
  cardiovascular: {
    name: 'Cardiovascular Function',
    icon: '❤️',
    description: 'Vascular stiffness, cardiac output, blood pressure regulation',
    population: generateCurve(95, 35, 'exponential', 2),
    superager: generateCurve(95, 75, 'superager', 1),
    unit: 'Function Index',
  },
  metabolic: {
    name: 'Metabolic Health',
    icon: '🔥',
    description: 'Glucose regulation, insulin sensitivity, lipid metabolism',
    population: generateCurve(92, 40, 'exponential', 2),
    superager: generateCurve(92, 72, 'superager', 1),
    unit: 'Metabolic Score',
  },
  inflammatory: {
    name: 'Inflammatory Markers',
    icon: '🛡️',
    description: 'hsCRP, IL-6, GDF-15, immune function',
    population: generateCurve(90, 30, 'exponential', 3),
    superager: generateCurve(90, 68, 'superager', 1),
    unit: 'Anti-inflammatory Index',
  },
  functional: {
    name: 'Physical Function',
    icon: '💪',
    description: 'Grip strength, gait speed, muscle mass, balance',
    population: generateCurve(95, 25, 'exponential', 2),
    superager: generateCurve(95, 70, 'superager', 1),
    unit: 'Functional Capacity',
  },
};

// SVG Chart Component
const TrajectoryChart = ({ domain, showGap, selectedAge }) => {
  const { population, superager, name, unit } = domains[domain];
  
  const width = 500;
  const height = 280;
  const padding = { top: 30, right: 30, bottom: 40, left: 50 };
  const chartWidth = width - padding.left - padding.right;
  const chartHeight = height - padding.top - padding.bottom;
  
  const xScale = (age) => padding.left + ((age - 30) / 70) * chartWidth;
  const yScale = (value) => padding.top + (1 - value / 100) * chartHeight;
  
  const createPath = (points) => {
    return points.map((p, i) => 
      `${i === 0 ? 'M' : 'L'} ${xScale(p.age)} ${yScale(p.value)}`
    ).join(' ');
  };
  
  // Create area path for the gap
  const createGapArea = () => {
    const topPath = superager.map(p => `${xScale(p.age)},${yScale(p.value)}`).join(' ');
    const bottomPath = [...population].reverse().map(p => `${xScale(p.age)},${yScale(p.value)}`).join(' ');
    return `M ${topPath} L ${bottomPath} Z`;
  };
  
  // Find values at selected age
  const popValue = population.find(p => p.age === selectedAge)?.value || 0;
  const saValue = superager.find(p => p.age === selectedAge)?.value || 0;
  const gap = saValue - popValue;
  
  return (
    <svg width={width} height={height} style={{ overflow: 'visible' }}>
      {/* Background */}
      <rect x={padding.left} y={padding.top} width={chartWidth} height={chartHeight} 
            fill={colors.cardBg} rx="4" />
      
      {/* Grid lines */}
      {[0, 25, 50, 75, 100].map(v => (
        <g key={v}>
          <line 
            x1={padding.left} y1={yScale(v)} 
            x2={width - padding.right} y2={yScale(v)}
            stroke={colors.gridLine} strokeDasharray="2,4"
          />
          <text x={padding.left - 8} y={yScale(v) + 4} 
                fill={colors.textMuted} fontSize="10" textAnchor="end">
            {v}
          </text>
        </g>
      ))}
      
      {/* X-axis labels */}
      {[30, 45, 60, 75, 90, 100].map(age => (
        <text key={age} x={xScale(age)} y={height - 10} 
              fill={colors.textMuted} fontSize="10" textAnchor="middle">
          {age}
        </text>
      ))}
      
      {/* Gap area */}
      {showGap && (
        <path d={createGapArea()} fill={colors.accentDim} opacity="0.4" />
      )}
      
      {/* Population curve */}
      <path 
        d={createPath(population)} 
        fill="none" 
        stroke={colors.warning} 
        strokeWidth="2.5"
        strokeLinecap="round"
      />
      
      {/* Super ager curve */}
      <path 
        d={createPath(superager)} 
        fill="none" 
        stroke={colors.accent} 
        strokeWidth="2.5"
        strokeLinecap="round"
      />
      
      {/* Selected age indicator */}
      <line 
        x1={xScale(selectedAge)} y1={padding.top} 
        x2={xScale(selectedAge)} y2={height - padding.bottom}
        stroke={colors.gold} strokeWidth="1.5" strokeDasharray="4,4" opacity="0.7"
      />
      
      {/* Data points at selected age */}
      <circle cx={xScale(selectedAge)} cy={yScale(popValue)} r="6" 
              fill={colors.warning} stroke={colors.background} strokeWidth="2" />
      <circle cx={xScale(selectedAge)} cy={yScale(saValue)} r="6" 
              fill={colors.accent} stroke={colors.background} strokeWidth="2" />
      
      {/* Gap annotation */}
      {showGap && gap > 5 && (
        <g>
          <line 
            x1={xScale(selectedAge) + 15} y1={yScale(popValue)}
            x2={xScale(selectedAge) + 15} y2={yScale(saValue)}
            stroke={colors.gold} strokeWidth="2"
            markerEnd="url(#arrowhead)" markerStart="url(#arrowhead)"
          />
          <rect 
            x={xScale(selectedAge) + 22} 
            y={(yScale(popValue) + yScale(saValue)) / 2 - 12}
            width="45" height="24" rx="4" fill={colors.background}
          />
          <text 
            x={xScale(selectedAge) + 45} 
            y={(yScale(popValue) + yScale(saValue)) / 2 + 5}
            fill={colors.gold} fontSize="12" fontWeight="bold" textAnchor="middle"
          >
            +{gap.toFixed(0)}%
          </text>
        </g>
      )}
      
      {/* Axis labels */}
      <text x={width / 2} y={height - 2} fill={colors.text} fontSize="11" textAnchor="middle">
        Age (years)
      </text>
      <text 
        transform={`translate(12, ${height / 2}) rotate(-90)`}
        fill={colors.text} fontSize="11" textAnchor="middle"
      >
        {unit}
      </text>
      
      {/* Arrow marker definition */}
      <defs>
        <marker id="arrowhead" markerWidth="6" markerHeight="6" refX="3" refY="3" orient="auto">
          <polygon points="0 0, 6 3, 0 6" fill={colors.gold} />
        </marker>
      </defs>
    </svg>
  );
};

// Stats card component
const StatCard = ({ label, value, subtext, color }) => (
  <div style={{
    background: colors.cardBg,
    borderRadius: '8px',
    padding: '16px',
    borderLeft: `3px solid ${color}`,
  }}>
    <div style={{ color: colors.textMuted, fontSize: '11px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
      {label}
    </div>
    <div style={{ color: color, fontSize: '28px', fontWeight: '700', marginTop: '4px' }}>
      {value}
    </div>
    <div style={{ color: colors.textMuted, fontSize: '12px', marginTop: '2px' }}>
      {subtext}
    </div>
  </div>
);

// Main component
export default function AgingTrajectoryDashboard() {
  const [selectedDomain, setSelectedDomain] = useState('cardiovascular');
  const [selectedAge, setSelectedAge] = useState(65);
  const [showGap, setShowGap] = useState(true);
  
  const domain = domains[selectedDomain];
  const popValue = domain.population.find(p => p.age === selectedAge)?.value || 0;
  const saValue = domain.superager.find(p => p.age === selectedAge)?.value || 0;
  const gap = saValue - popValue;
  
  // Calculate aggregate stats
  const avgGap = Object.values(domains).reduce((acc, d) => {
    const pv = d.population.find(p => p.age === selectedAge)?.value || 0;
    const sv = d.superager.find(p => p.age === selectedAge)?.value || 0;
    return acc + (sv - pv);
  }, 0) / 4;
  
  return (
    <div style={{
      minHeight: '100vh',
      background: `linear-gradient(135deg, ${colors.background} 0%, ${colors.secondary} 100%)`,
      color: colors.text,
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
      padding: '24px',
    }}>
      {/* Header */}
      <div style={{ marginBottom: '24px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '8px' }}>
          <div style={{
            background: `linear-gradient(135deg, ${colors.accent}, ${colors.secondary})`,
            borderRadius: '8px',
            padding: '8px 12px',
            fontSize: '12px',
            fontWeight: '600',
            letterSpacing: '1px',
          }}>
            NURAXI VITRUVIA
          </div>
          <div style={{
            background: colors.warningDim,
            color: colors.warning,
            borderRadius: '8px',
            padding: '8px 12px',
            fontSize: '12px',
            fontWeight: '600',
          }}>
            KSA POPULATION MODEL
          </div>
        </div>
        <h1 style={{ 
          fontSize: '28px', 
          fontWeight: '700', 
          margin: '0 0 8px 0',
          background: `linear-gradient(90deg, ${colors.text}, ${colors.accent})`,
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
        }}>
          Aging Trajectory Analysis
        </h1>
        <p style={{ color: colors.textMuted, margin: 0, fontSize: '14px' }}>
          Population-level curves vs. Super Ager reference trajectories derived from SardiNIA longitudinal data
        </p>
      </div>
      
      {/* Stats Row */}
      <div style={{ 
        display: 'grid', 
        gridTemplateColumns: 'repeat(4, 1fr)', 
        gap: '16px',
        marginBottom: '24px',
      }}>
        <StatCard 
          label="Intervention Potential"
          value={`+${avgGap.toFixed(0)}%`}
          subtext="Avg function gain at selected age"
          color={colors.gold}
        />
        <StatCard 
          label="Population n"
          value="34.1M"
          subtext="KSA target population"
          color={colors.accent}
        />
        <StatCard 
          label="Reference Cohort"
          value="1,224"
          subtext="Centenarians (AMORIS)"
          color={colors.accent}
        />
        <StatCard 
          label="Biological Age Gap"
          value={`${Math.round((100 - popValue) / 10 * 1.5)} yrs`}
          subtext="vs chronological at age {selectedAge}"
          color={colors.warning}
        />
      </div>
      
      {/* Main Content Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 300px', gap: '24px' }}>
        
        {/* Chart Section */}
        <div style={{
          background: colors.cardBg,
          borderRadius: '12px',
          padding: '20px',
          border: `1px solid ${colors.gridLine}`,
        }}>
          {/* Domain Tabs */}
          <div style={{ display: 'flex', gap: '8px', marginBottom: '16px', flexWrap: 'wrap' }}>
            {Object.entries(domains).map(([key, d]) => (
              <button
                key={key}
                onClick={() => setSelectedDomain(key)}
                style={{
                  background: selectedDomain === key ? colors.accent : 'transparent',
                  color: selectedDomain === key ? colors.background : colors.text,
                  border: `1px solid ${selectedDomain === key ? colors.accent : colors.gridLine}`,
                  borderRadius: '6px',
                  padding: '8px 14px',
                  fontSize: '13px',
                  fontWeight: '500',
                  cursor: 'pointer',
                  transition: 'all 0.2s',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                }}
              >
                <span>{d.icon}</span>
                {d.name}
              </button>
            ))}
          </div>
          
          {/* Chart */}
          <TrajectoryChart 
            domain={selectedDomain} 
            showGap={showGap}
            selectedAge={selectedAge}
          />
          
          {/* Age Slider */}
          <div style={{ marginTop: '20px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
              <span style={{ color: colors.textMuted, fontSize: '12px' }}>Selected Age</span>
              <span style={{ color: colors.gold, fontSize: '14px', fontWeight: '600' }}>{selectedAge} years</span>
            </div>
            <input 
              type="range" 
              min="30" max="100" step="5"
              value={selectedAge}
              onChange={(e) => setSelectedAge(Number(e.target.value))}
              style={{
                width: '100%',
                accentColor: colors.accent,
              }}
            />
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ color: colors.textMuted, fontSize: '10px' }}>30</span>
              <span style={{ color: colors.textMuted, fontSize: '10px' }}>100</span>
            </div>
          </div>
          
          {/* Legend */}
          <div style={{ 
            display: 'flex', 
            gap: '24px', 
            marginTop: '16px',
            paddingTop: '16px',
            borderTop: `1px solid ${colors.gridLine}`,
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <div style={{ width: '24px', height: '3px', background: colors.warning, borderRadius: '2px' }} />
              <span style={{ fontSize: '12px', color: colors.textMuted }}>KSA Population Average</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <div style={{ width: '24px', height: '3px', background: colors.accent, borderRadius: '2px' }} />
              <span style={{ fontSize: '12px', color: colors.textMuted }}>Super Ager Reference</span>
            </div>
            <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', marginLeft: 'auto' }}>
              <input 
                type="checkbox" 
                checked={showGap}
                onChange={(e) => setShowGap(e.target.checked)}
                style={{ accentColor: colors.accent }}
              />
              <span style={{ fontSize: '12px', color: colors.textMuted }}>Show Opportunity Gap</span>
            </label>
          </div>
        </div>
        
        {/* Right Panel */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          
          {/* Domain Info */}
          <div style={{
            background: colors.cardBg,
            borderRadius: '12px',
            padding: '20px',
            border: `1px solid ${colors.gridLine}`,
          }}>
            <div style={{ fontSize: '20px', marginBottom: '8px' }}>{domain.icon}</div>
            <h3 style={{ margin: '0 0 8px 0', fontSize: '16px', fontWeight: '600' }}>{domain.name}</h3>
            <p style={{ margin: '0 0 16px 0', fontSize: '13px', color: colors.textMuted, lineHeight: '1.5' }}>
              {domain.description}
            </p>
            
            <div style={{ 
              display: 'grid', 
              gridTemplateColumns: '1fr 1fr', 
              gap: '12px',
              padding: '12px',
              background: colors.background,
              borderRadius: '8px',
            }}>
              <div>
                <div style={{ fontSize: '10px', color: colors.textMuted, marginBottom: '2px' }}>POPULATION</div>
                <div style={{ fontSize: '20px', fontWeight: '700', color: colors.warning }}>{popValue.toFixed(0)}%</div>
              </div>
              <div>
                <div style={{ fontSize: '10px', color: colors.textMuted, marginBottom: '2px' }}>SUPER AGER</div>
                <div style={{ fontSize: '20px', fontWeight: '700', color: colors.accent }}>{saValue.toFixed(0)}%</div>
              </div>
            </div>
            
            <div style={{
              marginTop: '12px',
              padding: '12px',
              background: `linear-gradient(90deg, ${colors.background}, rgba(255, 215, 0, 0.1))`,
              borderRadius: '8px',
              borderLeft: `3px solid ${colors.gold}`,
            }}>
              <div style={{ fontSize: '10px', color: colors.gold, marginBottom: '2px' }}>INTERVENTION OPPORTUNITY</div>
              <div style={{ fontSize: '24px', fontWeight: '700', color: colors.gold }}>+{gap.toFixed(0)} points</div>
              <div style={{ fontSize: '11px', color: colors.textMuted }}>
                {gap > 30 ? 'High potential for improvement' : gap > 15 ? 'Moderate intervention benefit' : 'Closer to optimal trajectory'}
              </div>
            </div>
          </div>
          
          {/* Key Insights */}
          <div style={{
            background: colors.cardBg,
            borderRadius: '12px',
            padding: '20px',
            border: `1px solid ${colors.gridLine}`,
          }}>
            <h3 style={{ margin: '0 0 12px 0', fontSize: '14px', fontWeight: '600', color: colors.accent }}>
              Key Insights
            </h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              <div style={{ fontSize: '12px', color: colors.textMuted, lineHeight: '1.5' }}>
                <span style={{ color: colors.accent }}>●</span> Super agers show <strong style={{ color: colors.text }}>homogeneous biomarker profiles</strong> from age 65 onwards
              </div>
              <div style={{ fontSize: '12px', color: colors.textMuted, lineHeight: '1.5' }}>
                <span style={{ color: colors.accent }}>●</span> Centenarians spend only <strong style={{ color: colors.text }}>5.2-9.4%</strong> of life with age-related diseases
              </div>
              <div style={{ fontSize: '12px', color: colors.textMuted, lineHeight: '1.5' }}>
                <span style={{ color: colors.accent }}>●</span> The gap represents <strong style={{ color: colors.text }}>modifiable factors</strong> through personalized interventions
              </div>
            </div>
          </div>
          
          {/* Data Sources */}
          <div style={{
            background: colors.cardBg,
            borderRadius: '12px',
            padding: '16px',
            border: `1px solid ${colors.gridLine}`,
            fontSize: '11px',
            color: colors.textMuted,
          }}>
            <div style={{ fontWeight: '600', marginBottom: '8px', color: colors.text }}>Reference Data</div>
            <div>SardiNIA/ProgeNIA (n=6,148)</div>
            <div>Swedish AMORIS Centenarian Study (n=44,636)</div>
            <div>New England Centenarian Study (n=5,500+)</div>
            <div style={{ marginTop: '8px', color: colors.accent }}>SABA Sardinia Super Ager Cohort (n=1,600+)</div>
          </div>
        </div>
      </div>
      
      {/* Bottom Banner */}
      <div style={{
        marginTop: '24px',
        background: `linear-gradient(90deg, ${colors.secondary}, ${colors.cardBg})`,
        borderRadius: '12px',
        padding: '20px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        border: `1px solid ${colors.gridLine}`,
      }}>
        <div>
          <div style={{ fontSize: '14px', fontWeight: '600', marginBottom: '4px' }}>
            Vitruvia World Model: Predictive Aging Trajectories
          </div>
          <div style={{ fontSize: '12px', color: colors.textMuted }}>
            Trained on 25+ years of longitudinal biological data from exceptional agers
          </div>
        </div>
        <div style={{ display: 'flex', gap: '8px' }}>
          <div style={{
            background: colors.accent,
            color: colors.background,
            padding: '10px 20px',
            borderRadius: '6px',
            fontSize: '13px',
            fontWeight: '600',
          }}>
            Deploy for KSA Vision 2030
          </div>
        </div>
      </div>
    </div>
  );
}
